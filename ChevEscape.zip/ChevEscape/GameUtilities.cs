﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Media;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using GameUtilities;
using System.Timers;
using System.Threading;
using System.IO;
using ChevEscape;
using ChevEscape.Properties;

namespace GameUtilities
{

    public class GameGrid
    {
        public GameGrid()
        {
            this.CreateGameGrid();
        }

        public Point[,] GAME_GRID = new Point[ROWS, COLS];

        private const int ROWS = 18; //y
        private const int COLS = 18; //x
        private int GridTileWidth  = 32;
        private int GridTileHeight = 32;
        //private List<GameObject> inframeObjects = new List<GameObject>();
        private List<object> inframeObjects = new List<object>();

        private void CreateGameGrid()
        {
            for (int row = 0; row < ROWS;  row++ )
            {
                for (int col = 0;  col < COLS; col++)
                {
                    GAME_GRID[row, col].column = GridTileWidth  * col;
                    GAME_GRID[row, col].row    = GridTileHeight * row; 
                } // column
            } // row 
        } // create game grid

        /*
         * Add Game Objects to this Grid
         */
        public void addToGrid(GameObject obj)
        {
            inframeObjects.Add(obj);
        }
        public void addToGrid(Door obj)
        {
            inframeObjects.Add(obj);
        }
        public void addToGrid(ActionTile obj)
        {
            inframeObjects.Add(obj);
        }

        /*
         * Getter functions
         * 
         */

        public Point getPixelPosition(int row, int col)
        {
            return this.GAME_GRID[row, col];
        }

        public int getNumOfCols()
        {
            return COLS; 
        }

        public int getNumOfRows()
        {
            return ROWS;
        }
        public List<object> getObjectsOnGrid()
        {
            return inframeObjects;
        }


    } // GameGrid

    /*
     * A position on the Grid
     */
    public struct Point
    {
        public int row; //column
        public int column; // row

        public static bool operator ==(Point pointA, Point pointB)
        {
            if ((pointA.row == pointB.row) && (pointA.row == pointB.row))
            {
                return true;
            } // if statement

            return false;
        }

        public static bool operator !=(Point pointA, Point pointB)
        {
            if (!(pointA.row == pointB.row) && (pointA.row == pointB.row))
            {
                return true;
            } // if statement

            return false;
        }
    }

    public class HeartContainer
    {
        
        public HeartContainer(int id, PictureBox image)
        {
            icon = image;

            switch (id)
            {
                case 1:
                    icon.Top = POSITION_TOP;
                    icon.Left = HEART_A_POSITION_LEFT;
                    break;
                case 2:
                    icon.Top = POSITION_TOP;
                    icon.Left = HEART_B_POSITION_LEFT;
                    break;
                case 3:
                    icon.Top = POSITION_TOP;
                    icon.Left = HEART_C_POSITION_LEFT;
                    break;
                default:
                    icon.Top = POSITION_TOP;
                    icon.Left = HEART_C_POSITION_LEFT;
                    break;
            } // switch
        } // heart container


        private PictureBox icon = new PictureBox();
        private int heart_id;
        const int POSITION_TOP = 12;
        const int HEART_A_POSITION_LEFT = 412; //564
        const int HEART_B_POSITION_LEFT = 450; //564
        const int HEART_C_POSITION_LEFT = 488; //564

        public int getHeartID()
        {
            return heart_id;
        }

        public void setHeartState(int heartState)
        {
            switch(heartState)
            {
                case 0: // Heart is empty
                    icon.Image = ChevEscape.Properties.Resources.heart_empty;
                    break;
                case 1:
                    icon.Image = ChevEscape.Properties.Resources.heart_half;
                    break;
                case 2:
                    icon.Image = ChevEscape.Properties.Resources.heart_full;
                    break;
                default:
                    icon.Image = ChevEscape.Properties.Resources.heart_full;
                    break;

            } // switch
        } // set heart state
    }

    public class CloseButton
    {
        public CloseButton (PictureBox image)
        {
            icon = image;
            icon.Top = POSITION_TOP;
            icon.Left = POSITION_LEFT;
        }

        PictureBox icon;
        const int POSITION_TOP = 12; // 564
        const int POSITION_LEFT = 564; // 12

        /*
         * Exits the application after user confirms quitting
         * 
         */
        public void EndGame()
        {
            // Display a message box that asks the user to confirm tha they want to end the game
            //MessageBox.Show("Would you like to quit?", MessageBoxButtons.YesNo,);
            if (MessageBox.Show("Would you like to quit?", "Question", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                Application.Exit();
            }
            else
            {
                Console.WriteLine("Continue game...");
            }

        } // end game
    }

    public class PauseButton
    {
        // Change to form of class main menu
        public PauseButton(Form currForm, PictureBox image)
        {
            
            icon = image;
            icon.Top = POSITION_TOP;
            icon.Left = POSITION_LEFT;

            currentForm = currForm;


            
        } // Pause button

        PictureBox icon;
        Form currentForm;
        GameMenu mainMenu;

        const int POSITION_TOP = 12; //526
        const int POSITION_LEFT = 526; //12

        public void PauseGame()
        {
            // Disable game timer;
            if (MessageBox.Show("Continue playing?", "Question", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                // Enable game timer if implemented
            } // if 

            // Player does not want to continue
            else
            {
                if (MessageBox.Show("Would you like to go to the main menu?", "Question", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {
                    // Close the current form
                    Console.WriteLine("Going to main menu");
                    Program.gameManager.resetPuzzleRoomData(); // reset all puzzle data
                    mainMenu = new GameMenu();
                    mainMenu.Show();
                    currentForm.Hide();
                }
                else
                {
                    Console.WriteLine("Closing application");
                    Application.Exit();
                } // else - ending application
            } // else - the player does not want to continue playing
        } // Pause Game
    }

    /**
     * Toggles the in-game audio.
     **/
    public class MuteButton
    {
        // Constructor
        public MuteButton(PictureBox image)
        {
            // Set icon properties
            icon = image;
            icon.Top = POSITION_TOP;
            icon.Left = POSITION_LEFT;
        }

        // Destructor
        ~MuteButton() { /* Console.WriteLine("MuteButton desctructor called."); */ }

        // Member functions
        // Update menu icon
        public void updateIcon()
        {
            if (Program.gameManager.sfxValue()) icon.Image = Resources.Unmuted;
            else icon.Image = Resources.Muted;
        }

        // Mute/unmute game audio
        public void toggleSound()
        {
            // Change audio state
            Program.gameManager.sfxToggle();

            // Update icon
            updateIcon();
        }

        // Data members
        PictureBox icon;                // Contextual icon
        const int POSITION_TOP = 50;    // Y position
        const int POSITION_LEFT = 564;  // X position
    }

    /*
     * Player as a seperate Object in the game
     */
    public class Player
    {
        public Player(GameGrid grid, PictureBox pIcon, int row, int col)
        {
            icon = pIcon;
            map = grid;
            position.row = row;
            position.column = col;
            UpdatePositionOnScreen();
        }

        private GameGrid map;
        private PictureBox icon;
        private Point position;
        private bool canMove = true;
        
        // Walking animations
        private Image LEFT = ChevEscape.Properties.Resources.chev_mainPlayer;
        private Image RIGHT = ChevEscape.Properties.Resources.chev_walkingRight;
        private Image UP = ChevEscape.Properties.Resources.chev_walkingUp;
        private Image DOWN = ChevEscape.Properties.Resources.chev_walkingDown;

        // Keyboard controls
        private const int UP_KEY = 87;      // W
        private const int DOWN_KEY = 83;    // S
        private const int LEFT_KEY = 65;    // A
        private const int RIGHT_KEY = 68;   // D
        private const int ACTION_KEY = 70;  // F

        public void Move(int keyVal)
        {
            // If the player can't move
            if (!canMove)
                return;

            // If the player can move
            int index;
            switch (keyVal)
            {
                case UP_KEY:        // w - moving player up
                    index = position.row;
                    index--;
                    if (index >= 0 )
                    {
                        icon.Image = UP;
                        if (IsPositionPermissible(index, position.column))
                        {
                            position.row = index;                                   // update player to new position
                            Program.gameManager.sfxPlay(Resources.Footsteps, true); // play sound effect
                        } // if permissible
                    } // if in bounds
                    break;

                case RIGHT_KEY:     // d - moving player right
                    index = position.column;
                    index++;
                    if (index < map.getNumOfCols())
                    {
                        icon.Image = RIGHT;
                        if (IsPositionPermissible(position.row, index))
                        {
                            position.column = index;
                            Program.gameManager.sfxPlay(Resources.Footsteps, true);
                        }
                    }
                    break;

                case DOWN_KEY:      // s - Moving player down
                    index = position.row;
                    index++;
                    if (index < map.getNumOfRows())
                    {
                        icon.Image = DOWN;
                        if (IsPositionPermissible(index, position.column))
                        {
                            position.row = index;
                            Program.gameManager.sfxPlay(Resources.Footsteps, true);
                        }
                    }
                    break;

                case LEFT_KEY:      // a - moving player left
                    index = position.column;
                    index--;
                    if (index >= 0)
                    {
                        icon.Image = LEFT;
                        if (IsPositionPermissible(position.row, index))
                        {
                            position.column = index;
                            Program.gameManager.sfxPlay(Resources.Footsteps, true);
                        }
                    }
                    break;

                case ACTION_KEY:    // f - the action button
                    InteractWithActionTile();
                    break;

            } // switch statement
            UpdatePositionOnScreen();
        }

        private void InteractWithActionTile()
        {
            // find the object the user is interacting with
            // search the gamegrid for the object that is in the same position
            // as the player icon
            List<object> listOfObjects = map.getObjectsOnGrid();
            
            // search through all objects in the game
            foreach (var item in listOfObjects )
            {
                // check if the object is an actionTile
                ActionTile tile;
                if (item is ActionTile)
                {
                    // Check if player is in the position
                    tile = (ActionTile)item;
                    Point tPos = tile.getPosition(); 
                    if ((tPos.column == position.column) && (tPos.row == position.row))
                    {
                        tile.triggerEvent();
                        break;
                    }
                } // if
            } // for each loop
        } // InteractWithActionTile
        
        /*
         * Updates the player icon's position on the screen and updates the row and coloumn
         */
        private void UpdatePositionOnScreen()
        {
            //Change PictureBox position on screen
            Point objPoint = map.getPixelPosition(position.row, position.column);
            icon.Top = objPoint.row;
            icon.Left = objPoint.column;
        }
        
        /*
         * Enable or disable player's movement
         */
        void setMobility(bool move)
        {
            canMove = move;
        }

        /*
         * Checks to see if the position is permissible.
         */
        bool IsPositionPermissible(int row, int col)
        {
            // Search the game grid that the player is associated with for an object in
            // the row,col position.
            List<object> objList = map.getObjectsOnGrid();
            foreach (var obj in objList )
            {
                // Get the object
                var tempObj = (GameObject)obj;
                // check if the object is in that position
                Point tempObjPosition = tempObj.getPosition();
                if ((tempObjPosition.column == col) && (tempObjPosition.row == row))
                {
                    if (tempObj.isPermissible())
                        return true;
                    else
                        return false;

                } // if player's next position is in permissible
            } // for each object on the map.
            return true;
        } // IsPositionPermissible

        public int getPlayerCurrentPosition_Column()
        {
            return position.column;
        }
        public int getPlayerCurrentPosition_Row()
        {
            return position.row;
        }
        public int getControls_ActionKeyValue()
        {
            return ACTION_KEY;
        }

    } // Player class
    /*
     * Objects within the game
     */
    public class GameObject
    {

        public GameObject (GameGrid grid, PictureBox image, int row, int col, bool permObject = false)
        {
            map = grid;
            icon = image;
            position.row = row;
            position.column = col;
            permissible = permObject;
            UpdateObjectPosition();
        }

        protected GameGrid map;
        protected bool permissible;
        protected PictureBox icon;
        protected Point position;

        /*
         * Set the location onto the grid
         */
        public void UpdateObjectPosition() 
        {
            //Change PictureBox position on screen
            Point objPoint = map.getPixelPosition(position.row, position.column);
            icon.Top  = objPoint.row;
            icon.Left = objPoint.column;
        }

        public bool isPermissible()
        {
            return permissible;
        }

        public void togglePermissibility()
        {
            permissible = !permissible;
        }

        /*
         * 
         * Getter functions
         * 
         */
        public Point getPosition()
        {
            return position;
        }

    }

    /*
     * Instructions object
     */
     public class Instructions : GameObject
    {
        //string instructionsData;
        public Instructions(int pID, GameGrid map, PictureBox image, int row, int col) :
            base(map, image, row, col)
        {
            modal = new InstructionsModal();
            puzzleID = pID; 
        }

        InstructionsModal modal; 
        //string textInstruction;

        int puzzleID; 

        const int MEMORYPUZZLE_ID = 1;
        const int IMAGESCRAMBLER_ID = 2;
        const int COLORPUZZLE_ID = 3;
        const int BRAINBUSTERPUZZLE_ID = 4;
        const int MAINMENU_ID = 0;

        /*
         * Opens the modal
         */
        public void myEvent()
        {
            // Prepare the modal with the given string
            modal.prepareModal(getInstructions(puzzleID));

            // Show the modal
            modal.Show();

            // Play sound effect
            Program.gameManager.sfxPlay(Resources.Paper);
        }

        public string getInstructions(int puzzleID)
        {
            string fileName = "";
            string path = Directory.GetCurrentDirectory();
            //path = Directory.GetParent(path).FullName; //bin
            //path = Directory.GetParent(path).FullName;//chevEscape

            string instructions = "";
            Console.WriteLine(path);
            switch (puzzleID)
            {
                case MAINMENU_ID:
                    fileName = @"..\..\mainRoomInstructions.txt";
                    break;
                case MEMORYPUZZLE_ID:
                    fileName = @"..\..\memoryPuzzleInstructions.txt"; //System.IO.Path.Combine(path, "memoryPuzzleInstructions.txt");
                    break;
                case IMAGESCRAMBLER_ID:
                    fileName = @"..\..\imageScramblerInstructions.txt";  //System.IO.Path.Combine(path, "tempText.txt");
                    break;
                case COLORPUZZLE_ID:
                    fileName = @"..\..\colorPuzzleInstructions.txt"; //System.IO.Path.Combine(path, "colorPuzzleInstructions.txt");
                    break;
                case BRAINBUSTERPUZZLE_ID:
                    fileName = @"..\..\brainBusterPuzzleInstructions.txt";  //  System.IO.Path.Combine(path, "tempText.txt");
                    break;
            } // switch

            try
            {
                using ( StreamReader sr = new StreamReader(fileName))
                {
                    Console.WriteLine("Reading from file: ...");
                    Console.WriteLine(fileName);
                    instructions = sr.ReadToEnd();
                }
            }
            catch (IOException e)
            {
                Console.WriteLine("The file could not read.");
                Console.WriteLine(e.Message);
            }

            return instructions;
        } // get instructions

    } // Instructions class
    
    public class Indicator : GameObject
    {
        public Indicator(GameGrid grid, PictureBox image, int row, int col) :
            base(grid, image, row, col)
        {
            
        }

        Image correctImage = ChevEscape.Properties.Resources.indicator_correct;
        Image incorrectImage = ChevEscape.Properties.Resources.indicator_incorrect;
        Image neutralImage = ChevEscape.Properties.Resources.indicator_neutral;
        Image inProgressImage = ChevEscape.Properties.Resources.indicator_inProgress;

        

        public void showCorrectState()
        {
            icon.Image = correctImage;
        }

        public void showIncorrectState()
        {
            icon.Image = incorrectImage;
        }

        public void showNeutralState()
        {
            icon.Image = neutralImage;
        }

        public void showInProgressState()
        {
            icon.Image = inProgressImage;
        }

        public void resetMe()
        {
            if (icon.Image == neutralImage)
                return;
            else
                icon.Image = neutralImage;
        }
    }

    public class Door : GameObject
    {
        public Door(Form currRoom, Form lnRoom, GameGrid grid, PictureBox image, int row, int col) 
            : base(grid, image, row, col)
        {
            linkedRoom  = lnRoom;
            currentRoom = currRoom;
            //updatePosition(posX, posY);
        }

        protected Form linkedRoom;
        protected Form currentRoom;

        /*
         * Object event - Opens the linked form and hides the current one.
         */
        virtual public void myEvent()
        {
            // Hide current form
            if (currentRoom is MainRoom)
                currentRoom.Hide();
            else
                currentRoom.Close();
            
            // Open linked form
            linkedRoom.Show();

            // Play sound effect
            Program.gameManager.sfxPlay(Resources.DoorOpen);
        }
    } // Door object

    public class LockedDoor : Door
    {
        
        public LockedDoor(Form currForm, Form lnForm, GameGrid grid, PictureBox image, int row, int col) :
            base(currForm, lnForm, grid, image, row, col)
        {
            isUnlocked = false;
        }

        const int MEMORYPUZZLE_ID = 1;
        const int IMAGESCRAMBLER_ID = 2;
        const int COLORPUZZLE_ID = 3;
        const int BRAINBUSTERPUZZLE_ID = 4;

        bool isUnlocked;

        public override void myEvent()
        {
            checkIfUnlocked();
            //check if puzzle is unlocked
            if (isUnlocked)
            {
                // Show completion message box
                if (MessageBox.Show("Congratulations, you unlocked the door!", "Question", MessageBoxButtons.OK, MessageBoxIcon.Question) == DialogResult.OK)
                {
                } // if

                // Hide current form
                if (currentRoom is MainRoom)
                    currentRoom.Hide();
                else
                    currentRoom.Close();

                // Open linked form
                linkedRoom.Show();

                // Play sound effect
                Program.gameManager.sfxPlay(Resources.GameComplete);
            }
            else
            {
                // Play sound effect
                Program.gameManager.sfxPlay(Resources.DoorClose);

                // Show incompletion message box
                if (MessageBox.Show("You must complete all puzzles to continue", "Question", MessageBoxButtons.OK, MessageBoxIcon.Question) == DialogResult.OK)
                { 
                } // if
            }
        } // my event

        public void checkIfUnlocked()
        {
            if (Program.gameManager.getPuzzleCompletionStatus(MEMORYPUZZLE_ID))
            {
                if (Program.gameManager.getPuzzleCompletionStatus(IMAGESCRAMBLER_ID))
                {
                    if (Program.gameManager.getPuzzleCompletionStatus(COLORPUZZLE_ID))
                    {
                        if (Program.gameManager.getPuzzleCompletionStatus(BRAINBUSTERPUZZLE_ID))
                        {
                            isUnlocked = true;
                        } //brainbuster puzzle
                    } // color puzzle
                } // image scrambler
            } // memory puzzle

        } // checkIfUnlocked 
    } // Locked Door

    public class ActionTile : GameObject
    {
        
        public ActionTile(Door lnObj, GameGrid grid, PictureBox image, int row, int col, bool permObject = true) :
            base(grid, image, row, col, permObject)
        {
            linkedItem = lnObj;
            objectId = 1;
        }

        public ActionTile(FlashBinSwitch lnObj, GameGrid grid, PictureBox image, int row, int col, bool permObject = true) :
            base(grid, image, row, col, permObject)
        {
            linkedItem = lnObj;
            objectId = 2;
        }

        public ActionTile(SubmitSwitch lnObj, GameGrid grid, PictureBox image, int row, int col, bool permObject = true) :
           base(grid, image, row, col, permObject)
        {
            linkedItem = lnObj;
            objectId = 3;
        }
        public ActionTile(StartSwitch lnObj, GameGrid grid, PictureBox image, int row, int col, bool permObject = true) :
           base(grid, image, row, col, permObject)
        {
            linkedItem = lnObj;
            objectId = 4;
        }

        public ActionTile(Instructions lnObj, GameGrid grid, PictureBox image, int row, int col, bool permObject = true) :
           base(grid, image, row, col, permObject)
        {
            linkedItem = lnObj;
            objectId = 5;
        }

        public ActionTile(LockedDoor lnObj, GameGrid grid, PictureBox image, int row, int col, bool permObject = true) :
           base(grid, image, row, col, permObject)
        {
            linkedItem = lnObj;
            objectId = 6;
        }

        public ActionTile(ColorBlock lnObj, GameGrid grid, PictureBox image, int row, int col, bool permObject = true) :
           base(grid, image, row, col, permObject)
        {
            linkedItem = lnObj;
            objectId = 7;
        }

        public ActionTile(ImageTable lnObj, GameGrid grid, PictureBox image, int row, int col, bool permObject = true) :
           base(grid, image, row, col, permObject)
        {
            linkedItem = lnObj;
            objectId = 8;
        }

        public ActionTile(BrainBusterManager lnObj, GameGrid grid, PictureBox image, int row, int col, bool permObject = true) :
            base(grid, image, row, col, permObject)
        {
            linkedItem = lnObj;
            objectId = 9;
        }

        object linkedItem;
        int objectId;

        public void triggerEvent()
        {
            switch (objectId)
            {
                case 1:
                    ((Door)linkedItem).myEvent();
                    break;
                case 2:
                    ((FlashBinSwitch)linkedItem).myEvent();
                    break;
                case 3:
                    ((SubmitSwitch)linkedItem).myEvent();
                    break;
                case 4:
                    ((StartSwitch)linkedItem).myEvent();
                    break;
                case 5:
                    ((Instructions)linkedItem).myEvent();
                    break;
                case 6:
                    ((LockedDoor)linkedItem).myEvent();
                    break;
                case 7:
                    ((ColorBlock)linkedItem).myEvent();
                    break;
                case 8:
                    ((ImageTable)linkedItem).myEvent();
                    break;
                case 9:
                    ((BrainBusterManager)linkedItem).myEvent();
                    break;
            } // switch statement
        }


    } // Action Tile

    /*
     * Game manager manages all aspects of the game
     */
    public class GameManager
    {
        public GameManager()
        {
            playerSavedLocation.column = 9;
            playerSavedLocation.row = 9;
            sfx = true;
        }

        // Constant variables for each puzzle's ID
        const int MEMORYPUZZLE_ID   = 1;
        const int IMAGESCRAMBLER_ID = 2;
        const int COLORPUZZLE_ID    = 3;
        const int BRAINBUSTERPUZZLE_ID = 4;

        // Puzzle Data
        PuzzleRoomData memoryPuzzleData = new PuzzleRoomData(MEMORYPUZZLE_ID);
        PuzzleRoomData imagePuzzleData  = new PuzzleRoomData(IMAGESCRAMBLER_ID);
        PuzzleRoomData colorPuzzleData  = new PuzzleRoomData(COLORPUZZLE_ID);
        PuzzleRoomData brainbusterPuzzleData = new PuzzleRoomData(BRAINBUSTERPUZZLE_ID);

        // Player data
        Point playerSavedLocation = new Point();    // Player location
        int GAME_ATTEMPTS = 6;                      // Puzzle attempts
        bool sfx;                                   // Game audio setting

        /**
         * Audio setting
         **/
        // Gets player's current audio setting
        public bool sfxValue() { return sfx; }

        // Toggles the game audio
        public void sfxToggle() { sfx = !sfx; }

        /**
         * Plays a game sound from a given resource file if the sfx
         *  setting has not been muted by the player.
         * @param   file    - name of audio resource
         *          var     - if the sound effect is randomized
         **/
        public void sfxPlay(Stream file)
        {
            // If sound effects are not muted
            if (sfx)
            {
                // Create SoundPlayer
                SoundPlayer sound = new SoundPlayer(file);

                // Output sound
                sound.Play();
            }

            // If sound effects are muted
            else return;
        }

        public void sfxPlay(Stream file, bool var)
        {
            // If sound effects are not muted
            if (sfx)
            {
                // Determine sound effect variability
                if (var)
                {
                    // Generate random number between 1-5
                    Random rnd = new Random();
                    int num = rnd.Next(1, 6);

                    // Select randomized footstep sound
                    switch (num)
                    {
                        case 1: file = Resources.Footstep_1; break;
                        case 2: file = Resources.Footstep_2; break;
                        case 3: file = Resources.Footstep_3; break;
                        case 4: file = Resources.Footstep_4; break;
                        case 5: file = Resources.Footstep_5; break;
                    }
                }

                // Create SoundPlayer
                SoundPlayer sound = new SoundPlayer(file);

                // Output sound
                sound.Play();
            }

            // If sound effects are muted
            else return;
        }

        public struct PuzzleRoomData
        {
            public PuzzleRoomData(int pID)
            {
                puzzleID = pID;
                isCompleted = false;
            }

            public int puzzleID;
            public bool isCompleted;

            public void setCompletionStatus(bool status)
            {
                isCompleted = status;
            }

            public bool getCompletionStatus()
            {
                return isCompleted;
            }
        }

        /*
         *  Obtains if the puzzle is complete or incomplete
         */
        public bool getPuzzleCompletionStatus(int puzzleID)
        {
            switch (puzzleID)
            {
                case MEMORYPUZZLE_ID:
                    return memoryPuzzleData.getCompletionStatus();
                    break;
                case IMAGESCRAMBLER_ID:
                    return imagePuzzleData.getCompletionStatus();
                    break;
                case COLORPUZZLE_ID:
                    return colorPuzzleData.getCompletionStatus();
                    break;
                case BRAINBUSTERPUZZLE_ID:
                    return brainbusterPuzzleData.getCompletionStatus();
                    break;
            } // switch
            return false;
        } // getPuzzleStatus

        /*
         * Sets the puzzle's completion status.
         */
        public void setPuzzleCompletionStatus(int pID, bool isComplete)
        {
            // Determine which puzzle is complete
            switch (pID)
            {
                case MEMORYPUZZLE_ID:       memoryPuzzleData.setCompletionStatus(isComplete);       break;
                case IMAGESCRAMBLER_ID:     imagePuzzleData.setCompletionStatus(isComplete);        break;
                case COLORPUZZLE_ID:        colorPuzzleData.setCompletionStatus(isComplete);        break;
                case BRAINBUSTERPUZZLE_ID:  brainbusterPuzzleData.setCompletionStatus(isComplete);  break;
            } // switch
        }

        public void resetPuzzleRoomData()
        {
            memoryPuzzleData.setCompletionStatus(false);
            imagePuzzleData.setCompletionStatus(false);
            colorPuzzleData.setCompletionStatus(false);
            brainbusterPuzzleData.setCompletionStatus(false);
            GAME_ATTEMPTS = 6;
        } // resetPuzzleRoomData

        /*
         * Updates the players attempts / Lives
         */
        public void decrementAttempts()
        {
            // Decrement player's remaining puzzle attempts
            GAME_ATTEMPTS--;

            // Play sound effect for heart loss
            sfxPlay(Resources.Oof);
        }

        public void updatePlayersHeartContainer(HeartContainer heartA, HeartContainer heartB, HeartContainer heartC)
        {
            const int FIRST_HEART = 1;
            const int SECOND_HEART = 2;
            const int THIRD_HEART = 3;

            HeartContainer firstHeart = heartA;
            HeartContainer secondHeart = heartB;
            HeartContainer thirdHeart = heartC;

            /*
             * Verify each heart container parameter
             */
            switch(heartA.getHeartID())
            {
                case FIRST_HEART: // if it is the first heart
                    firstHeart = heartA;
                    break;
                case SECOND_HEART:
                    secondHeart = heartA;
                    break;

                case THIRD_HEART:
                    thirdHeart = heartA;
                    break;
            }

            switch (heartB.getHeartID())
            {
                case FIRST_HEART: // if it is the first heart
                    firstHeart = heartB;
                    break;
                case SECOND_HEART:
                    secondHeart = heartB;
                    break;

                case THIRD_HEART:
                    thirdHeart = heartB;
                    break;
            }

            switch (heartC.getHeartID())
            {
                case FIRST_HEART: // if it is the first heart
                    firstHeart = heartC;
                    break;
                case SECOND_HEART:
                    secondHeart = heartC;
                    break;

                case THIRD_HEART:
                    thirdHeart = heartC;
                    break;
            }

            // Read the number of attempts the player has

            if (GAME_ATTEMPTS == 0)
            {
                heartA.setHeartState(0);
                heartB.setHeartState(0);
                heartC.setHeartState(0);
            }

            else if (GAME_ATTEMPTS == 1)
            {
                heartA.setHeartState(1);
                heartB.setHeartState(0);
                heartC.setHeartState(0);
            }

            else if (GAME_ATTEMPTS == 2)
            {
                heartA.setHeartState(2);
                heartB.setHeartState(0);
                heartC.setHeartState(0);
            }

            else if (GAME_ATTEMPTS == 3)
            {
                heartA.setHeartState(2);
                heartB.setHeartState(1);
                heartC.setHeartState(0);
            }

            else if (GAME_ATTEMPTS == 4)
            {
                heartA.setHeartState(2);
                heartB.setHeartState(2);
                heartC.setHeartState(0);
            }

            else if (GAME_ATTEMPTS == 5)
            {
                heartA.setHeartState(2);
                heartB.setHeartState(2);
                heartC.setHeartState(1);
            }

            else if (GAME_ATTEMPTS == 6)
            {
                heartA.setHeartState(2);
                heartB.setHeartState(2);
                heartC.setHeartState(2);
            }
            
        }

        /*
         * Player's saved location
         */
        public void setPlayerSavedPosition(int row, int col)
        {
            playerSavedLocation.row = row;
            playerSavedLocation.column = col;
        }

        public int getPlayerSavedPosition_row() { return playerSavedLocation.row; }

        public int getPlayerSavedPosition_column() { return playerSavedLocation.column; }

        /*
         * Add to key up function for every room
         */
        public void CheckIfGameIsOver(Form closingForm)
        {
            if (GAME_ATTEMPTS == 0)
            {
                if (MessageBox.Show("Game Over! Would you like to go to the main menu?", "Question", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {
                    closingForm.Hide();
                    Form menuScreen = new GameMenu();
                    menuScreen.Show();
                    resetPuzzleRoomData();
                }
                else
                {
                    Console.WriteLine("Ending Scene...");
                    Application.Exit();
                }
            }
        } // check if game is over
    } // GameManager
}
