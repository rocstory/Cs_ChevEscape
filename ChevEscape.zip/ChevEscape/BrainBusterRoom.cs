﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using GameUtilities;

namespace ChevEscape
{
    public partial class BrainBusterRoom : Form
    {
        // GameUtilities components
        GameGrid map = new GameGrid();
        Player player;
        Form main_room;

        // Counts how many hearts the player has left
        HeartContainer heartA;
        HeartContainer heartB;
        HeartContainer heartC;

        // Used to identify this puzzle's number
        public const int puzzleID = 4;

        // Will increase on each iteration of the puzzle
        public int count = 0;

        // Interactive buttons
        CloseButton close_Button;
        PauseButton pause_Button;
        MuteButton mute_Button;

        // Puzzle Manager
        BrainBusterManager pBrainBusterManager;

        // Constructor
        public BrainBusterRoom()
        {
            InitializeComponent();
        }

        // Called when the Form is loaded
        private void BrainBusterRoom_Load(object sender, EventArgs e)
        {
            InitializeGameComponents();
            Program.gameManager.updatePlayersHeartContainer(heartA, heartB, heartC);
            mute_Button.updateIcon();
        }

        // Function that initializes all variables and objects needed to run the puzzle
        private void InitializeGameComponents()
        {
            // Used to interact with the door
            main_room = new MainRoom();

            // Sets the player on the grid
            player = new Player(map, main_player, 9, 3);

            // Interactive buttons
            close_Button = new CloseButton(closeButton);
            pause_Button = new PauseButton(this, pauseButton);
            mute_Button = new MuteButton(muteButton);

            // Setting heart container on screen
            heartA = new HeartContainer(1, heartContainerA);
            heartB = new HeartContainer(2, heartContainerB);
            heartC = new HeartContainer(3, heartContainerC);

            // Will lead player back to the main room form
            Door door = new Door(this, main_room, map, door_A, 9, 2);
            door_A.Image.RotateFlip(RotateFlipType.Rotate90FlipX);

            // Tells the player whether they finished the puzzle 
            Indicator indicator = new Indicator(map, indicatorBb, 3, 9);

            // Door action tile
            ActionTile doorAT = new ActionTile(door, map, actionTile_door, 9, 3);

            // Game instructions
            Instructions instructions = new Instructions(puzzleID, map, instructionsIcon, 8, 2);
            ActionTile instructionsAT = new ActionTile(instructions, map, actionTile_instructions, 8, 3);

            // Panel that shows the directions
            BrainBusterPanel move_Panel = new BrainBusterPanel(map, movePanel, 4, 7, 0);

            // Panels that determine whether game is correct, wrong, running, or waiting for input
            BrainBusterPanel correct_Panel = new BrainBusterPanel(map, correctPanel, 3, 7, 1);
            correctPanel.Image.RotateFlip(RotateFlipType.Rotate270FlipNone);
            BrainBusterPanel wrong_Panel = new BrainBusterPanel(map, wrongPanel, 3, 8, 1);
            wrongPanel.Image.RotateFlip(RotateFlipType.Rotate90FlipNone);
            BrainBusterPanel running_Panel = new BrainBusterPanel(map, runningPanel, 3, 10, 1);
            BrainBusterPanel waiting_Panel = new BrainBusterPanel(map, waitingForInput, 3, 11, 1);
            waitingForInput.Image.RotateFlip(RotateFlipType.Rotate180FlipNone);


            // Movement delimiters after puzzle begins
            BrainBusterPanel leftGate = new BrainBusterPanel(map, gatePanel1, 9, 8, 4);
            BrainBusterPanel rightGate = new BrainBusterPanel(map, gatePanel2, 9, 10, 4);
            BrainBusterPanel downGate = new BrainBusterPanel(map, gatePanel3, 10, 9, 4);
            BrainBusterPanel upGate = new BrainBusterPanel(map, gatePanel4, 8, 9, 4);

            // Puzzle manager implementation
            pBrainBusterManager = new BrainBusterManager(player, move_Panel, correct_Panel, wrong_Panel, running_Panel, waiting_Panel,
                leftGate, rightGate, downGate, upGate, indicator);

            // Action tile for the puzzle game
            ActionTile brainBusterAT = new ActionTile(pBrainBusterManager, map, actionTile_Game, 9, 9);

            // Sets the manager of each object
            move_Panel.setManager(pBrainBusterManager);
            correct_Panel.setManager(pBrainBusterManager);
            wrong_Panel.setManager(pBrainBusterManager);
            running_Panel.setManager(pBrainBusterManager);
            waiting_Panel.setManager(pBrainBusterManager);

            leftGate.setManager(pBrainBusterManager);
            rightGate.setManager(pBrainBusterManager);
            downGate.setManager(pBrainBusterManager);

            // set the assets onto the map

            map.addToGrid(door);
            map.addToGrid(doorAT);

            map.addToGrid(instructionsAT);
            map.addToGrid(instructions);

            map.addToGrid(move_Panel);
            map.addToGrid(correct_Panel);
            map.addToGrid(wrong_Panel);
            map.addToGrid(running_Panel);
            map.addToGrid(waiting_Panel);

            map.addToGrid(leftGate);
            map.addToGrid(rightGate);
            map.addToGrid(downGate);
            map.addToGrid(upGate);

            map.addToGrid(brainBusterAT);

            map.addToGrid(indicator);

        } // end InitializeGameComponents()

        // Event handler for when a keyboard key is pressed
        private void BrainBusterRoom_KeyUp(object sender, KeyEventArgs e)
        {
            player.Move(e.KeyValue);

            if (e.KeyValue != 0)
                pBrainBusterManager.setKey(e.KeyValue);

            Program.gameManager.CheckIfGameIsOver(this);
            Program.gameManager.updatePlayersHeartContainer(heartA, heartB, heartC);
        }

        // Event handler for when the closebutton is clicked
        private void closeButton_Click(object sender, EventArgs e)
        {
            close_Button.EndGame();
        }

        // Event handler for when the pausebutton is clicked
        private void pauseButton_Click(object sender, EventArgs e)
        {
            pause_Button.PauseGame();
        }

        // Event handler for when the mute button is clicked
        private void muteButton_Click(object sender, EventArgs e)
        {
            mute_Button.toggleSound();
        }
    } // end BrainBusterRoom : Form

    // Game manager
    public class BrainBusterManager : BrainBusterRoom
    {
        // Constructor
        public BrainBusterManager(Player p, BrainBusterPanel moveP, BrainBusterPanel cPanel, BrainBusterPanel wPanel, BrainBusterPanel runP, BrainBusterPanel waitP,
    BrainBusterPanel lGate, BrainBusterPanel rGate, BrainBusterPanel dGate, BrainBusterPanel uGate, Indicator indctr)
        {
            player = p;

            indicator = indctr;

            move_Panel = moveP;
            correct_Panel = cPanel;
            wrong_Panel = wPanel;
            running_Panel = runP;
            waiting_Panel = waitP;

            left_Gate = lGate;
            right_Gate = rGate;
            down_Gate = dGate;
            up_Gate = uGate;

            animationTimer = new System.Timers.Timer();
            animationTimer.Enabled = false;
            animationTimer.AutoReset = true;
            animationTimer.Interval = timeThreshold;
            animationTimer.Elapsed += animationTimer_Tick;


            Console.WriteLine("Entered brainBusterManager, hitKey = " + hitKey);
        }

        // Attributes ------------------------------

        Player player;

        const int puzzleID = 4;
        private int counter = 0;
        private int direction;
        private int hitKey;
        private const int iterations = 8;

        private Indicator indicator;

        protected System.Timers.Timer animationTimer;
        protected float timeThreshold = 2000;

        public BrainBusterPanel move_Panel;
        public BrainBusterPanel correct_Panel;
        public BrainBusterPanel wrong_Panel;
        public BrainBusterPanel running_Panel;
        public BrainBusterPanel waiting_Panel;

        public BrainBusterPanel left_Gate;
        public BrainBusterPanel right_Gate;
        public BrainBusterPanel down_Gate;
        public BrainBusterPanel up_Gate;

        // values for changing pictures
        public const int neutralPanel = 0;
        public const int neutralAnswer = 1;
        public const int correctNum = 4;
        public const int correctNeutral = 1;
        public const int wrongNum = 5;
        public const int wrongNeutral = 2;
        public const int runningNum = 6;
        public const int runningNeutral = 3;
        public const int waitingNum = 7;
        public const int waitingNeutral = 4;

        // Key values 
        private int[] keys = { 65, 68, 87, 83,
                                0, 0, 0, 0,
                                65, 68, 87, 83 }; // A D W S

        public void setKey(int v)
        {
            hitKey = v;
        }

        // Function that changes the directions of the move_Panel
        public void randomizePanels()
        {
            waiting_Panel.changePicture(waitingNum);
            correct_Panel.changeToNeutral(correctNeutral);
            wrong_Panel.changeToNeutral(wrongNeutral);

            Random random = new Random();
            if (count < iterations)
            {
                direction = random.Next(0, 4); // phase 1
                move_Panel.changePicture(direction);
            }
            else if (count < iterations * 2)
            {
                direction = random.Next(8, 12); // phase 2
                move_Panel.changePicture(direction);
            }

            animationTimer.Enabled = true;

        }

        // Called when the ActionTile is clicked
        public void myEvent()
        {
            timeThreshold = 2000; // make sure to always reset the time threshold
            // if the game did not start yet
            if (counter == 0)
            {
                left_Gate.togglePermissibility();
                right_Gate.togglePermissibility();
                down_Gate.togglePermissibility();
                up_Gate.togglePermissibility();

                running_Panel.changePicture(runningNum);

                // make sure that no key is automatically selected
                setKey(0);

                randomizePanels();

                counter++;

                if (count == iterations * 2)
                {
                    indicator.showCorrectState();
                    Program.gameManager.setPuzzleCompletionStatus(puzzleID, true);
                    Program.gameManager.sfxPlay(Properties.Resources.PuzzleComplete);
                    move_Panel.changeToNeutral(neutralPanel);

                    // If puzzle is completed, allow player to move again
                    left_Gate.togglePermissibility();
                    right_Gate.togglePermissibility();
                    down_Gate.togglePermissibility();
                    up_Gate.togglePermissibility();
                }
            }
            else
            {
                move_Panel.changeToNeutral(neutralPanel);
                waiting_Panel.changeToNeutral(waitingNeutral);
                correct_Panel.changeToNeutral(correctNeutral);
                wrong_Panel.changeToNeutral(wrongNeutral);

                left_Gate.togglePermissibility();
                right_Gate.togglePermissibility();
                down_Gate.togglePermissibility();
                up_Gate.togglePermissibility();

                running_Panel.changeToNeutral(runningNeutral);

                counter--;
                count = 0;

            }
        }

        // Allows player to have some time to input their key while also checking whether they were right or not
        public void animationTimer_Tick(object sender, System.Timers.ElapsedEventArgs e)
        {
            if (count < iterations)
            {
                if (hitKey == keys[direction])
                {
                    count++;
                    timeThreshold -= 100;
                    setKey(0); // reset key
                    correct_Panel.changePicture(correctNum);
                    waiting_Panel.changeToNeutral(waitingNeutral);
                    move_Panel.changeToNeutral(neutralPanel);
                    animationTimer.Enabled = false;
                    System.Threading.Thread.Sleep(500);
                    randomizePanels();
                }
                else
                {
                    timeThreshold = 2000; // reset
                    setKey(0); // reset key
                    wrong_Panel.changePicture(wrongNum);
                    waiting_Panel.changeToNeutral(waitingNeutral);
                    move_Panel.changeToNeutral(neutralPanel);
                    running_Panel.changeToNeutral(runningNeutral);
                    Program.gameManager.decrementAttempts();
                    animationTimer.Enabled = false;
                }
            }

            else if (count < iterations * 2) // phase 2 of game
            {
                if (hitKey != keys[direction])
                {
                    count++;
                    timeThreshold -= 100;
                    setKey(0); // reset key
                    correct_Panel.changePicture(correctNum);
                    waiting_Panel.changeToNeutral(waitingNeutral);
                    move_Panel.changeToNeutral(neutralPanel);
                    animationTimer.Enabled = false;
                    System.Threading.Thread.Sleep(500);
                    randomizePanels();
                }
                else
                {
                    setKey(0); // reset key
                    timeThreshold = 2000;
                    wrong_Panel.changePicture(wrongNum);
                    waiting_Panel.changeToNeutral(waitingNeutral);
                    move_Panel.changeToNeutral(neutralPanel);
                    Program.gameManager.decrementAttempts();
                    animationTimer.Enabled = false;
                }
            }

            else
            {
                indicator.showCorrectState();
                Program.gameManager.setPuzzleCompletionStatus(puzzleID, true);
                Program.gameManager.sfxPlay(Properties.Resources.PuzzleComplete);
                move_Panel.changeToNeutral(neutralPanel);
                running_Panel.changeToNeutral(runningNeutral);
                waiting_Panel.changeToNeutral(waitingNeutral);
                animationTimer.Enabled = false;
            }

        }
    } // end BrainBusterManager

    // Panels used as game objects in the BrainBusterRoom
    public class BrainBusterPanel : GameObject
    {
        // Constructor
        public BrainBusterPanel(GameGrid grid, PictureBox image, int row, int col, int pID) :
            base(grid, image, row, col)
        {
            panelID = pID;
            if (pID == 4) //if they start as a gate, make them permissible
            {
                this.togglePermissibility();
            }
        }

        // Data members
        protected int panelID;
        protected BrainBusterManager puzzleManager = null;
        protected bool correctDirection = false; // determines if player clicked the right direction

        // Member functions
        public void setManager(BrainBusterManager manager)
        {
            puzzleManager = manager;
        }

        // Change the color of the panel to indicate direction
        public void changePicture(int pID)
        {
            switch (pID)
            {
                case 0: // left
                    this.icon.Image = Properties.Resources.bbLeft;
                    break;
                case 1: // right
                    this.icon.Image = Properties.Resources.bbRight;
                    break;
                case 2: // up
                    this.icon.Image = Properties.Resources.bbUp;
                    break;
                case 3: // down
                    this.icon.Image = Properties.Resources.bbDown;
                    break;
                case 4: // correct panel
                    this.icon.Image = Properties.Resources.panel_green;
                    this.icon.Image.RotateFlip(RotateFlipType.Rotate270FlipNone);
                    break;
                case 5: // wrong panel
                    this.icon.Image = Properties.Resources.panel_red;
                    this.icon.Image.RotateFlip(RotateFlipType.Rotate90FlipNone);
                    break;
                case 6: // running panel
                    this.icon.Image = Properties.Resources.panel_blue;
                    break;
                case 7: // waiting for input panel
                    this.icon.Image = Properties.Resources.panel_yellow;
                    this.icon.Image.RotateFlip(RotateFlipType.Rotate180FlipNone);
                    break;
                case 8: // not left
                    this.icon.Image = Properties.Resources.bbNotLeft;
                    break;
                case 9: // not right
                    this.icon.Image = Properties.Resources.bbNotRight;
                    break;
                case 10: // not up
                    this.icon.Image = Properties.Resources.bbNotUp;
                    break;
                case 11: // not down
                    this.icon.Image = Properties.Resources.bbNotDown;
                    break;
            }
        }

        // Change colors back to neutral
        public void changeToNeutral(int pID)
        {
            switch (pID)
            {
                case 0: // puzzle
                    this.icon.Image = Properties.Resources.bbBlank;
                    break;
                case 1: // correct
                    this.icon.Image = Properties.Resources.panel_neutral;
                    this.icon.Image.RotateFlip(RotateFlipType.Rotate270FlipNone);
                    break;
                case 2: // wrong
                    this.icon.Image = Properties.Resources.panel_neutral;
                    this.icon.Image.RotateFlip(RotateFlipType.Rotate90FlipNone);
                    break;
                case 3: // running
                    this.icon.Image = Properties.Resources.panel_neutral;
                    break;
                case 4: // waiting input
                    this.icon.Image = Properties.Resources.panel_neutral;
                    this.icon.Image.RotateFlip(RotateFlipType.Rotate180FlipNone);
                    break;
            }

        }
    } // end BrainBusterPanel

} // end ChevEscape
