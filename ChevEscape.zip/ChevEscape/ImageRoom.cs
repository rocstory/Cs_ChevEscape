﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using GameUtilities;

namespace ChevEscape
{
    public partial class ImageRoom : Form
    {
        GameGrid map = new GameGrid();
        Player player;
        Form main_room;
        public const int IMAGEPUZZLE_ID = 2;

        // Prepare the modal with the given string
        ImageScrambler Scrambler = new ImageScrambler();

        CloseButton closeButton;
        PauseButton pauseButton;
        MuteButton muteButton;

        HeartContainer heart1;
        HeartContainer heart2;
        HeartContainer heart3;

        public ImageRoom()
        {
            InitializeComponent();
        }

        private void ImageRoom_Load(object sender, EventArgs e)
        {
            InitializeGameComponents();
            Program.gameManager.updatePlayersHeartContainer(heart1, heart2, heart3);
            muteButton.updateIcon();
        }

        private void InitializeGameComponents()
        {
            // Load buttons/forms
            main_room = new MainRoom();
            closeButton = new CloseButton(button_close);
            pauseButton = new PauseButton(this, button_pause);
            muteButton = new MuteButton(button_mute);

            // Player
            player = new Player(map, main_player, 9, 15);

            // Door
            door_PB.Image.RotateFlip(RotateFlipType.Rotate90FlipNone);
            actionTile_Door.Image.RotateFlip(RotateFlipType.Rotate90FlipNone);
            Door door = new Door(this, main_room, map, door_PB, 9, 16);
            ActionTile doorAT = new ActionTile(door, map, actionTile_Door, 9, 15);

            // Instructions
            instructionsIcon.Image.RotateFlip(RotateFlipType.Rotate90FlipNone);
            actionTile_Instructions.Image.RotateFlip(RotateFlipType.Rotate90FlipNone);
            Instructions instructions = new Instructions(IMAGEPUZZLE_ID, map, instructionsIcon, 8, 16);
            ActionTile instructionsAT = new ActionTile(instructions, map, actionTile_Instructions, 8, 15);

            // Image Scrambler table
            ImageTable tableUpperRight = new ImageTable(map, desk_upperRightIcon, 9, 9);
            ImageTable tableLowerRight = new ImageTable(map, desk_lowerRightIcon, 10, 9);
            ImageTable tableLowerLeft = new ImageTable(map, desk_lowerLeftIcon, 10,8);
            ImageTable tableUpperLeft = new ImageTable(map, desk_upperLeftIcon, 9, 8);

            // Action tile puzzle start
            ActionTile tableAT = new ActionTile(tableLowerRight, map, actionTile_imageScramblerObject, 11, 9);

            // Load puzzle assets
            map.addToGrid(door);
            map.addToGrid(doorAT);
            map.addToGrid(instructions);
            map.addToGrid(instructionsAT);
            map.addToGrid(tableUpperRight);
            map.addToGrid(tableLowerRight);
            map.addToGrid(tableLowerLeft);
            map.addToGrid(tableUpperLeft);
            map.addToGrid(tableAT);

            // Initialize heart containers
            heart1 = new HeartContainer(1, heartContainer1);
            heart2 = new HeartContainer(2, heartContainer2);
            heart3 = new HeartContainer(3, heartContainer3);
        }

        private void Button_close_Click(object sender, EventArgs e)
        {
            closeButton.EndGame();
        }

        private void Button_pause_Click(object sender, EventArgs e)
        {
            pauseButton.PauseGame();
        }

        private void ImageRoom_KeyUp(object sender, KeyEventArgs e)
        {
            player.Move(e.KeyValue);
            Program.gameManager.updatePlayersHeartContainer(heart1, heart2, heart3);

        }

        private void button_mute_Click(object sender, EventArgs e)
        {
            muteButton.toggleSound();
        }
    } // ImageRoom

    public class ImageTable : GameObject
    {
        public ImageTable(GameGrid map, PictureBox image, int row, int col) :
            base(map, image, row, col)
        {

        }

        public void myEvent()
        {
            // Prepare the modal with the given string
            ImageScrambler Scrambler = new ImageScrambler();
            // Show the modal
            Scrambler.Show();
                
        }
    }

}
