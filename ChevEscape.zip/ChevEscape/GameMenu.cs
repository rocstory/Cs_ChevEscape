﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ChevEscape
{
    public partial class GameMenu : Form
    {
        public GameMenu()
        {
            InitializeComponent();
        }

        private void Button_play_Click(object sender, EventArgs e)
        {
            // Close the main screen

            // Open the player screen
            this.Hide();
            //MainRoom startingRoom = new MainRoom();
            //gameManager
            InstructionsScene tutorialMenu = new InstructionsScene();
            //startingRoom.Show();
            tutorialMenu.Show();
        }

        private void Button_play_MouseHover(object sender, EventArgs e)
        {
            // Change background to highlighted background
            button_play.Image = Properties.Resources.buttonBGMainScreenHighlighted;
        }

        private void Button_play_MouseLeave(object sender, EventArgs e)
        {
            button_play.Image = Properties.Resources.buttonBGMainScreen;
            
        }


        private void Button_exit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void Button_exit_MouseHover(object sender, EventArgs e)
        {
            button_exit.Image = Properties.Resources.buttonBGMainScreenHighlighted;
        }

        private void Button_exit_MouseLeave(object sender, EventArgs e)
        {
            button_exit.Image = Properties.Resources.buttonBGMainScreen;
        }

        private void TextBox1_TextChanged(object sender, EventArgs e)
        {

        }
    } // Game Menu 
}
