﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using GameUtilities;
using System.Timers;
using System.Threading;

namespace ChevEscape
{

    public partial class MemoryRoom : Form
    {
        GameGrid map = new GameGrid();
        Player player;
        Form main_room;
        MemoryPuzzleManager pMemoryManager;

        public const int puzzleID = 1;
        CloseButton closeButton;
        PauseButton pauseButton;
        MuteButton muteButton;

        HeartContainer heartA;
        HeartContainer heartB;
        HeartContainer heartC;


        public MemoryRoom()
        {
            InitializeComponent();
        }

        private void MemoryRoom_Load(object sender, EventArgs e)
        {
            InitializeGameComponents();
            Program.gameManager.updatePlayersHeartContainer(heartA, heartB, heartC);
            muteButton.updateIcon();
        }

        private void InitializeGameComponents()
        {
            main_room = new MainRoom();

            player = new Player(map, main_player, 15, 9);

            closeButton = new CloseButton(button_close);
            pauseButton = new PauseButton(this, button_pause);
            muteButton = new MuteButton(button_mute);

            // Setting heart container on screen
            heartA = new HeartContainer(1, heartContainerA);
            heartB = new HeartContainer(2, heartContainerB);
            heartC = new HeartContainer(3, heartContainerC);

            Door door = new Door(this, main_room, map, door_A, 16, 9);
            door_A.Image.RotateFlip(RotateFlipType.Rotate180FlipNone);

            ActionTile doorAT = new ActionTile(door, map, actionTile_Door, 15, 9);

            //Adding the flash bins and switches
            FlashBin redFlashBin = new FlashBin(0, map, flashBin_Red, 3, 4);
            FlashBinSwitch redSwitch = new FlashBinSwitch(redFlashBin, map, switch_redBin, 10, 4);
            ActionTile redSwitchAT = new ActionTile(redSwitch, map, actionTile_redSwitch, 11, 4);

            FlashBin blueFlashBin = new FlashBin(1, map, flashBin_Blue, 3, 6);
            FlashBinSwitch blueSwitch = new FlashBinSwitch(blueFlashBin, map, switch_blueBin, 10, 6);
            ActionTile blueSwitchAT = new ActionTile(blueSwitch, map, actionTile_blueSwitch, 11, 6);

            FlashBin greenFlashBin = new FlashBin(2, map, flashBin_Green, 3, 8);
            FlashBinSwitch greenSwitch = new FlashBinSwitch(greenFlashBin, map, switch_greenBin, 10, 8);
            ActionTile greenSwitchAT = new ActionTile(greenSwitch, map, actionTile_greenSwitch, 11, 8);

            FlashBin yellowFlashBin = new FlashBin(3, map, flashBin_Yellow, 3, 10);
            FlashBinSwitch yellowSwitch = new FlashBinSwitch(yellowFlashBin, map, switch_yellowBin, 10, 10);
            ActionTile yellowSwitchAT = new ActionTile(yellowSwitch, map, actionTile_yellowSwitch, 11, 10);

            StartSwitch startSwitch = new StartSwitch(map, switch_beginPuzzle, 10, 14);
            ActionTile startSwitchAT = new ActionTile(startSwitch, map, actionTile_beginSwitch, 11, 14);

            SubmitSwitch submitSwitch = new SubmitSwitch(startSwitch, map, switch_submit, 10, 12);
            ActionTile submitSwitchAT = new ActionTile(submitSwitch, map, actionTile_submitSwitch, 11, 12);

            Indicator indicator = new Indicator(map, indicatorPB, 9, 14);
            ProgressBar progressBar = new ProgressBar(progressBar_PB, map, 9, 12);

            Instructions instructions = new Instructions(puzzleID, map, instructionsIcon, 10, 16);
            ActionTile instructionsAT = new ActionTile(instructions, map, actionTile_Instructions, 11, 16);

            


            pMemoryManager = new MemoryPuzzleManager(startSwitch, submitSwitch, redFlashBin, blueFlashBin, greenFlashBin, yellowFlashBin, redSwitch, blueSwitch, greenSwitch, yellowSwitch, indicator, progressBar);

            startSwitch.setManager(pMemoryManager);
            submitSwitch.setManager(pMemoryManager);
            redSwitch.setManager(pMemoryManager);
            blueSwitch.setManager(pMemoryManager);
            greenSwitch.setManager(pMemoryManager);
            yellowSwitch.setManager(pMemoryManager);

            // set the assets onto the map

            map.addToGrid(door);
            map.addToGrid(doorAT);

            map.addToGrid(redFlashBin);
            map.addToGrid(redSwitch);
            map.addToGrid(redSwitchAT);

            map.addToGrid(blueFlashBin);
            map.addToGrid(blueSwitch);
            map.addToGrid(blueSwitchAT);

            map.addToGrid(greenFlashBin);
            map.addToGrid(greenSwitch);
            map.addToGrid(greenSwitchAT);

            map.addToGrid(yellowFlashBin);
            map.addToGrid(yellowSwitch);
            map.addToGrid(yellowSwitchAT);

            map.addToGrid(startSwitch);
            map.addToGrid(startSwitchAT);

            map.addToGrid(submitSwitch);
            map.addToGrid(submitSwitchAT);
            map.addToGrid(indicator);
            map.addToGrid(instructionsAT);
            map.addToGrid(instructions);
            map.addToGrid(progressBar);


            pMemoryManager.verifyPuzzleStatus();

        }

        private void MemoryRoom_KeyUp(object sender, KeyEventArgs e)
        {
            Program.gameManager.CheckIfGameIsOver(this);
            Program.gameManager.updatePlayersHeartContainer(heartA, heartB, heartC);
            player.Move(e.KeyValue);
        }

        private void MemoryRoom_FormClosing(object sender, FormClosingEventArgs e)
        {

        }

        private void Button_close_Click(object sender, EventArgs e)
        {
            closeButton.EndGame();
        }

        private void Button_pause_Click(object sender, EventArgs e)
        {
            pauseButton.PauseGame();
        }

        private void button_mute_Click(object sender, EventArgs e)
        {
            muteButton.toggleSound();
        }
    } //memory Room Class

    public class MemoryPuzzleManager
    {

        public MemoryPuzzleManager(StartSwitch startSwitch, SubmitSwitch submitSwitch, FlashBin redBin, FlashBin blueBin,
            FlashBin greenBin, FlashBin yellowBin, FlashBinSwitch redSwitch, FlashBinSwitch blueSwitch,
            FlashBinSwitch greenSwitch, FlashBinSwitch yellowSwitch, Indicator theIndicator, ProgressBar progress_bar)
        {

            // Bin Switches
            switch_red = redSwitch;
            switch_blue = blueSwitch;
            switch_green = greenSwitch;
            switch_yellow = yellowSwitch;

            //Bins
            bin_red = redBin;
            bin_blue = blueBin;
            bin_green = greenBin;
            bin_yellow = yellowBin;

            // Start and submit switches
            switch_start = startSwitch;
            switch_submit = submitSwitch;

            // Timer intilization
            flashTimer = new System.Timers.Timer();
            flashTimer.Interval = 2700;
            flashTimer.Elapsed += showSequence_Tick;
            flashTimer.Enabled = false;

            // Indicator
            indicator = theIndicator;

            // Indicator timer
            inputIndication = new System.Timers.Timer();
            inputIndication.Interval = 500;
            inputIndication.Elapsed += inputIndication_Tick;

            progressBar = progress_bar;

        }

        bool isPuzzleStarted = false;

        /*
         *          Attributes
         */

        const int puzzleID = 1;
        private int attempts = 3;
        private int numCorrect = 0;

        int sequenceLength = 4; // 4
        int seqIterator = 0;

        const int NUM_OF_SEQUENCES = 4; // 4

        private List<int> puzzleSequence;
        private List<int> playerInput = new List<int>();

        private System.Timers.Timer flashTimer;
        private System.Timers.Timer inputIndication;

        // Indicator
        private Indicator indicator;

        // flash bin switches
        private FlashBinSwitch switch_red;
        private FlashBinSwitch switch_blue;
        private FlashBinSwitch switch_green;
        private FlashBinSwitch switch_yellow;

        // flash bins
        private FlashBin bin_red;
        private FlashBin bin_blue;
        private FlashBin bin_yellow;
        private FlashBin bin_green;

        // submit and start switch
        StartSwitch switch_start;
        SubmitSwitch switch_submit;

        ProgressBar progressBar;

        /*
         * Begin displaying the generated puzzle sequence...
         * Is called when the player triggers the start switch
         */
        public void beginPuzzle()
        {
            
            progressBar.updateProgress(playerInput.Count()); // Update the progressBar
            indicator.resetMe();                    // Reset the indicator
            puzzleSequence = generateSequence();    // Generate new sequence
            enableFlashBinsOnly();                  // Allow flashbins to flash
            disableBinSwitchesOnly();               // Disable all flash bin switches
                                                    // 
            if (switch_submit.getAvailability())    // Disable the submit switch if it has not been disabled - Prevent user from interacting with object
                switch_submit.disableSwitch();      // ---
            flashTimer.Enabled = true;              // Start displaying the sequence...
            indicator.showInProgressState();        // Indicate to player that the sequence is in progress
        } // begin puzzle

        private void showSequence_Tick(object sender, System.Timers.ElapsedEventArgs e)
        {
            if (puzzleSequence.Count == 0)
                return;

            FlashBin currBin = null;


            // Check if the seqIterator is less than the sequence length
            if (seqIterator < sequenceLength)                  // If the sequence has another bin to flash
            {
                // identify the bin within the sequence
                switch (puzzleSequence[seqIterator])
                {
                    case 0: // Flash the Red Bin
                        currBin = bin_red;
                        break;
                    case 1:
                        currBin = bin_blue;
                        break;
                    case 2:
                        currBin = bin_green;
                        break;
                    case 3:
                        currBin = bin_yellow;
                        break;
                }

                Console.WriteLine("Flashing Bin Id: {0}", puzzleSequence[seqIterator]);
                currBin.myEvent();                             // Flash the identified flashbin
                seqIterator++;                                 // Move on to the next flashbin in the sequence
            }

            else
            {
                Console.WriteLine("Ending sequence...");
                seqIterator = 0;                                // Reset sequence iterator
                flashTimer.Enabled = false;                     // stop the timer 
                indicator.showNeutralState();                   // Show neutral state
                enableAllObjects();                             // Enable all flashbins, flashbin switches, and the submit switch
            } // else
        } //showSequence_Tick

        private void inputIndication_Tick(object sender, System.Timers.ElapsedEventArgs e)
        {
            indicator.showNeutralState();
            inputIndication.Enabled = false;
        } //showSequence_Tick

        public void addPlayerInput(int input)
        {

            Console.WriteLine("Player selected: {0}", input);
            indicator.showInProgressState();
            inputIndication.Enabled = true;
            playerInput.Add(input);
            progressBar.updateProgress(playerInput.Count());
        } // addPlayerInput

        public void clearPlayerInput()
        {
            playerInput.Clear();
        } // clearPlayerInput

        public List<int> generateSequence()
        {
            Random random = new Random();
            List<int> generatedSequence = new List<int>();

            for (int i = 0; i < sequenceLength; i++)
            {
                generatedSequence.Add(random.Next(0, 4));
            }
            return generatedSequence;
        } // generateSequence 

        public bool isSequenceCorrect()
        {
            for (int i = 0; i < sequenceLength; i++)        //Compare the player's input with the generated sequence
            {
                int mpSeq = puzzleSequence[i];
                int pInput = playerInput[i];
                if (mpSeq != pInput)                        // IF the player's input does not match return false.
                {
                    Console.WriteLine("No match {0}:{1}", puzzleSequence[i], playerInput[i]);
                    return false;
                }
            }
            Console.WriteLine("All Matches!");              // Player's input matches the generated sequence
            return true;
        } // isSequenceCorrect

        public void checkPlayersInput()
        {
            if (isSequenceCorrect())                        // If the player's input is correct... 
            {
                Console.WriteLine("Sequence is correct!");
                indicator.showCorrectState();               // Display the 'correct' image on the indicator
                numCorrect++;                               // Increment number of correct input
            }
            else
            {
                Console.WriteLine("Sequence is incorrect!");
                indicator.showIncorrectState();             // Display the 'incorrect' image on the indicator
                attempts--;                                 // Decrement the number of attempts that can be made by the player
            }
            // Allow the player to start a new sequence by enabling the start switch
            monitorPuzzleStatus();

            if (!switch_start.getAvailability())
                switch_start.enableSwitch();
        }

        public void monitorPuzzleStatus()
        {
            if (attempts == 0 || numCorrect == NUM_OF_SEQUENCES) // Puzzle game over - player either lost or won
            {
                // Disable submit and start switch if they are not already disabled
                disableAllObjects(); // Disable submit and start switch 

                if (numCorrect == NUM_OF_SEQUENCES)                 // If player solved x amount of sequences...
                {
                    // Set all flash bin colors to green indicating puzzle complete
                    Image greenIcon = bin_green.getImage();
                    bin_red.setImage(greenIcon);
                    bin_green.setImage(greenIcon);
                    bin_blue.setImage(greenIcon);
                    bin_yellow.setImage(greenIcon);

                    // Notify game manager that puzzle is complete
                    Program.gameManager.setPuzzleCompletionStatus(puzzleID, true);
                }
                else if (attempts == 0)                             // If player failed to solve the puzzle...
                {
                    // Decrement puzzle attempts
                    Program.gameManager.decrementAttempts();

                    // Set all flash bin colors to red indicating failure
                    Image redIcon = bin_red.getImage();
                    bin_blue.setImage(redIcon);
                    bin_green.setImage(redIcon);
                    bin_yellow.setImage(redIcon);
                    bin_green.setImage(redIcon);
                }
                else if (Program.gameManager.getPuzzleCompletionStatus(puzzleID)) // The puzzle has already been completed.
                {
                    Image greenIcon = bin_green.getImage();
                    bin_red.setImage(greenIcon);
                    bin_green.setImage(greenIcon);
                    bin_blue.setImage(greenIcon);
                    bin_yellow.setImage(greenIcon);
                }

            } // if game over
            else if (attempts > 0)                                  // Clear the player's input
            {
                clearPlayerInput();
                switch_start.resetMe();
                disableBinSwitchesOnly();
            }

            // display what will happen when user gets it right.

        } // monitorPuzzleStatus

        public void verifyPuzzleStatus()
        {
            if (Program.gameManager.getPuzzleCompletionStatus(puzzleID)) // if puzzle is completed...
            {
                disableAllObjects();            // Disable all objects
                indicator.showCorrectState();   // Set indicator status

                // Set all bins to green
                Image greenIcon = bin_green.getImage();
                bin_red.setImage(greenIcon);
                bin_green.setImage(greenIcon);
                bin_blue.setImage(greenIcon);
                bin_yellow.setImage(greenIcon);
            }
        }

        /*
         *                          Accessor methods
         */
        public int getPlayerInputLength() { return playerInput.Count(); }

        public int getSequenceLength() { return puzzleSequence.Count(); }

        /*
         *                  Disabling and Enabling functions
         */

        public void enableAllObjects()
        {
            // Flashbins
            if (!bin_red.checkAvailability())
                bin_red.toggleAvailability();
            if (!bin_blue.checkAvailability())
                bin_blue.toggleAvailability();
            if (!bin_green.checkAvailability())
                bin_green.toggleAvailability();
            if (!bin_yellow.checkAvailability())
                bin_yellow.toggleAvailability();

            // Submit switch
            if (!switch_submit.getAvailability())
                switch_submit.enableSwitch();

            // FlashBin Switches
            if (!switch_red.getAvailability())
                switch_red.enableSwitch();

            if (!switch_blue.getAvailability())
                switch_blue.enableSwitch();

            if (!switch_green.getAvailability())
                switch_green.enableSwitch();

            if (!switch_yellow.getAvailability())
                switch_yellow.enableSwitch();

        } // enable all objects

        public void disableAllObjects()
        {
            // Flashbins
            if (!bin_red.checkAvailability())
                bin_red.toggleAvailability();
            if (!bin_blue.checkAvailability())
                bin_blue.toggleAvailability();
            if (!bin_green.checkAvailability())
                bin_green.toggleAvailability();
            if (!bin_yellow.checkAvailability())
                bin_yellow.toggleAvailability();

            // Submit switch
            if (!switch_submit.getAvailability())
                switch_submit.enableSwitch();

            // Start switch
            if (!switch_start.getAvailability())
                switch_start.enableSwitch();


            // FlashBin Switches
            if (!switch_red.getAvailability())
                switch_red.enableSwitch();
            if (!switch_blue.getAvailability())
                switch_blue.enableSwitch();
            if (!switch_green.getAvailability())
                switch_green.enableSwitch();
            if (!switch_yellow.getAvailability())
                switch_yellow.enableSwitch();

        } // enable all objects

        // Flashbins
        public void enableFlashBinsOnly()
        {

            if (!bin_red.checkAvailability())
                bin_red.toggleAvailability();

            if (!bin_blue.checkAvailability())
                bin_blue.toggleAvailability();

            if (!bin_green.checkAvailability())
                bin_green.toggleAvailability();

            if (!bin_yellow.checkAvailability())
                bin_yellow.toggleAvailability();
        }
        public void disableFlashBinsOnly()
        {
            if (bin_red.checkAvailability())
                bin_red.toggleAvailability();

            if (bin_blue.checkAvailability())
                bin_blue.toggleAvailability();

            if (bin_green.checkAvailability())
                bin_green.toggleAvailability();

            if (bin_yellow.checkAvailability())
                bin_yellow.toggleAvailability();
        }

        // Flashbin Switches
        public void disableBinSwitchesOnly()
        {
            if (switch_red.getAvailability())
                switch_red.disableSwitch();

            if (switch_blue.getAvailability())
                switch_blue.disableSwitch();

            if (switch_green.getAvailability())
                switch_green.disableSwitch();

            if (switch_yellow.getAvailability())
                switch_yellow.disableSwitch();
        } // disable bins

        public void enableBinSwitchesOnly()
        {
            if (!switch_red.getAvailability())
                switch_red.enableSwitch();
            if (!switch_blue.getAvailability())
                switch_blue.enableSwitch();
            if (!switch_green.getAvailability())
                switch_green.enableSwitch();
            if (!switch_yellow.getAvailability())
                switch_yellow.enableSwitch();
        }

    } // MemoryPuzzleManager

    public class MemorySwitch : GameObject
    {

        /*
         *  Constructor
         */
        public MemorySwitch(GameGrid grid, PictureBox image, int row, int col) :
            base(grid, image, row, col)
        {
            animationTimer = new System.Timers.Timer();
            animationTimer.Enabled = false;
            animationTimer.Interval = 400;
            animationTimer.Elapsed += SwitchAnimation_Tick;
        }

        /*
         * Attributes
         */
        protected MemoryPuzzleManager puzzleManager = null;
        protected bool currentState = false; // determines if switch's current state
        protected bool isEnabled = true;  // determines if the switch is able to be used or not
        protected System.Timers.Timer animationTimer;

        /*
         * This Switch's event function
         */
        public virtual void myEvent()
        {
            Console.Write("Simple switch...");
        }

        /*
         * Reset switch's state and availability back to their original conditions
         */
        public void resetMe()
        {
            if (currentState)
                currentState = false;
            if (!isEnabled)
                isEnabled = true;
        }

        /*
         *  Disable this switch
         */
        public void disableSwitch()
        {
            if (isEnabled)                   // If the switch is enabled...
            {
                isEnabled = false;           // disable switch...
            }
        }

        /*
         *  Enable this switch
         *      Allow the player to interact with the switch
         */
        public void enableSwitch() { if (!isEnabled) { isEnabled = true; } } // enable switch


        /*
         *              Mutator methods
         */
        public void setManager(MemoryPuzzleManager manager) { puzzleManager = manager; }

        public virtual void AnimateMe() { this.icon.Image = Properties.Resources.switchButton_active; }

        private void SwitchAnimation_Tick(object sender, System.Timers.ElapsedEventArgs e)
        {
            this.ResetAnimation();
            animationTimer.Enabled = false;
        } // Flashbin tick

        public virtual void ResetAnimation() { this.icon.Image = Properties.Resources.switchButton_idle; }

        /*
         *               Accessor methods
         */

        public bool getCurrentState() { return currentState; }

        public bool getAvailability() { return isEnabled; }

        public void toggleState()
        {
            if (currentState) currentState = false;
            else currentState = true;
        }


    } // Memory Switch class 

    public class FlashBinSwitch : MemorySwitch
    {
        /*
         * Constructor
         */
        public FlashBinSwitch(FlashBin lnBin, GameGrid grid, PictureBox image, int row, int col) :
            base(grid, image, row, col)
        {
            linkedBin = lnBin;
        }

        private FlashBin linkedBin;

        /*
         * Signals the flashBin to begin flashing
         */
        override public void myEvent()
        {
            //int inputLength = puzzleManager.getPlayerInputLength();
            //int sequenceLength = puzzleManager.getSequenceLength();

            if (linkedBin.checkAvailability() && isEnabled)                 // If the bin is available and if this switch is enabled...
            {

                int inputLength = puzzleManager.getPlayerInputLength();     // Get the length of the player's input and the puzzle's sequence length
                int sequenceLength = puzzleManager.getSequenceLength();
                if (inputLength == sequenceLength) return;                  // Do not accept more than the sequence length
                AnimateMe();
                animationTimer.Enabled = true;                              // Animate switch
                Program.gameManager.sfxPlay(Properties.Resources.SwitchOn); // Play sound effect
                puzzleManager.addPlayerInput(linkedBin.getFlashBinId());    // Add the player's input 
                linkedBin.myEvent(); // Flashes the bin                     // Flash the selected bin
            } // if bin is available
        } // myEvent

        /*
         * Sets the switch to an active image 
         */
        override public void AnimateMe()
        {
            /* FlashBin game object
             * idNum - {0} Red {1} Blue {2} Green {3} Yellow 
             * 
             */

            const int RED = 0;
            const int BLUE = 1;
            const int GREEN = 2;
            const int YELLOW = 3;


            switch (linkedBin.getFlashBinId())
            {
                case RED:
                    this.icon.Image = Properties.Resources.red_switchButton_active;
                    break;
                case BLUE:
                    this.icon.Image = Properties.Resources.blue_switchButton_active;
                    break;
                case GREEN:
                    this.icon.Image = Properties.Resources.green_switchButton_active;
                    break;
                case YELLOW:
                    this.icon.Image = Properties.Resources.yellow_switchButton_active;
                    break;
            } // switch
        }

        /*
        protected void SwitchAnimation_Tick(object sender, System.Timers.ElapsedEventArgs e)
        {
            this.ResetAnimation();
            animationTimer.Enabled = false;
        } // Flashbin tick
        */

        override public void ResetAnimation()
        {
            const int RED = 0;
            const int BLUE = 1;
            const int GREEN = 2;
            const int YELLOW = 3;


            switch (linkedBin.getFlashBinId())
            {
                case RED:
                    this.icon.Image = Properties.Resources.red_switchButton_idle;
                    break;
                case BLUE:
                    this.icon.Image = Properties.Resources.blue_switchButton_idle;
                    break;
                case GREEN:
                    this.icon.Image = Properties.Resources.green_switchButton_idle;
                    break;
                case YELLOW:
                    this.icon.Image = Properties.Resources.yellow_switchButton_idle;
                    break;
            } // switch
        }


    } //FlashBinSwitch

    public class StartSwitch : MemorySwitch
    {

        public StartSwitch(GameGrid grid, PictureBox image, int row, int col) :
            base(grid, image, row, col)
        {

        }

        //MemoryPuzzleManager puzzleManager = null;
        //private bool isActivated = false; // determines if the switch is active or inactive
        //private bool isEnabled = true;

        new public void myEvent()
        {
            if (isEnabled)                          // If switch is enabled...
            {
                if (!currentState)                   // If switch isnt already active...       
                {
                    AnimateMe();
                    animationTimer.Enabled = true;
                    Program.gameManager.sfxPlay(Properties.Resources.SwitchOn); // Play sound effect
                    currentState = true;             // Make the switch active
                    puzzleManager.beginPuzzle();    // Notify the puzzle manager to begin puzzle
                } // if not activated
            } // if switch is enabled 
        } // my event


    } // Start Switch

    public class SubmitSwitch : MemorySwitch
    {
        public SubmitSwitch(StartSwitch starter, GameGrid grid, PictureBox image, int row, int col) :
            base(grid, image, row, col)
        {
            start_switch = starter;
        }

        private StartSwitch start_switch;

        /*
         * Checks the player's submission.
         */
        new public void myEvent()
        {

            if (!currentState && start_switch.getCurrentState())              // If this submission switch is off and the start switch is on...
            {
                int seqLength = puzzleManager.getSequenceLength();
                int playerInput = puzzleManager.getPlayerInputLength();

                if (playerInput == 0)                                       // Dont check player's submission if there is no input...
                {
                    Console.WriteLine("Sequence is empty");
                    return;
                }
                else if (playerInput < seqLength)                           // Don't check player's submission if they did not enter sufficient amount of input...
                {
                    Console.WriteLine("Not enough player input, {0}/{1}", playerInput, seqLength);
                    return;
                }
                AnimateMe();
                animationTimer.Enabled = true;
                Program.gameManager.sfxPlay(Properties.Resources.SwitchOn); // Play sound effect
                puzzleManager.checkPlayersInput();                          // Check if the player is correct
            } // if the submit switch has been activated
        } // myEvent method

        override public void AnimateMe()
        {
            this.icon.Image = Properties.Resources.purple_switchButton_active;
        }

        public override void ResetAnimation()
        {
            this.icon.Image = Properties.Resources.purple_switchButton_idle;

        }

    } // Submit Switch class
    
    public class FlashBin : GameObject
    {
        /* FlashBin game object
         * idNum - {0} Red {1} Blue {2} Green {3} Yellow 
         * 
         */
        public FlashBin(int idNum, GameGrid grid, PictureBox image, int row, int col) :
            base(grid, image, row, col)
        {
            flashBinID = idNum;
            myImage = image.Image;
            binState = true;
            numOfFlashes = 1;

            myTimer = new System.Timers.Timer();
            myTimer.Interval = 500; // seconds 
            myTimer.Elapsed += FlashBin_Tick;
            myTimer.Enabled = false;
        }

        private int flashBinID;
        private Image myImage;
        private bool binState;
        private System.Timers.Timer myTimer;
        private int numOfFlashes;
        private bool isEnabled = false; // disable flashbin until the player begins puzzle

        // Flashes bin
        public void myEvent()
        {
            // Save the image of the object
            //toggleState();
            if (isEnabled)
                myTimer.Enabled = true;
        }

        public Image getImage()
        {
            return myImage;
        }

        public void setImage(Image newImage)
        {
            this.icon.Image = newImage;
        }

        /*
         * Toggles if the bin is on or off
         */
        private void toggleState()
        {
            if (binState)
            {
                icon.Image = null;
                //icon.Image.Dispose();
                binState = false;
            }
            else
            {
                icon.Image = myImage;
                binState = true;
            }
        } // Toggle State

        public int getFlashBinId()
        {
            return flashBinID;
        }

        public bool getState()
        {
            return binState;
        }

        public void toggleAvailability()
        {
            if (isEnabled)
                isEnabled = false;
            else
                isEnabled = true;
        }

        /*
         * Check if the bin is able to flash.
         */
        public bool checkAvailability()
        {
            return isEnabled;
        }

        private void FlashBin_Tick(object sender, System.Timers.ElapsedEventArgs e)
        {
            if (numOfFlashes >= 5)
            {
                //Console.WriteLine("Done Flashing! Num:" + numOfFlashes + " State: " + binState);
                myTimer.Enabled = false;
                numOfFlashes = 1;
            }
            else
            {
                //Console.WriteLine("Flashing Bin! Num:" + numOfFlashes + " State: " + binState);
                toggleState();
                //linkedBin.myEvent();
                numOfFlashes++;
            }
        } // Flashbin tick
    }   // FlashBin class

    public class ProgressBar : GameObject
    {
        public ProgressBar(PictureBox image, GameGrid map, int row, int col) :
            base(map, image,  row, col)
        {

        }
        Image initial = Properties.Resources.progressBarA_p0;
        Image stageA = Properties.Resources.progressBarA_p1;
        Image stageB = Properties.Resources.progressBarA_p2;
        Image stageC = Properties.Resources.progressBarA_p3;
        Image stageD = Properties.Resources.progressBarA_p4;

        const int SEQUENCE_LENGTH = 4;
        public void updateProgress(int numOfInput)
        {
            int progressAmount = numOfInput % (SEQUENCE_LENGTH + 1);
            
            switch(progressAmount)
            {
                case 0:
                    icon.Image = initial;
                    break;
                case 1:
                    icon.Image = stageA;
                    break;
                case 2:
                    icon.Image = stageB;
                    break;
                case 3:
                    icon.Image = stageC;
                    break;
                case 4:
                    icon.Image = stageD;
                    break;
            } // switch statement
        }// updateProgress


    }

} // ChevEscape











