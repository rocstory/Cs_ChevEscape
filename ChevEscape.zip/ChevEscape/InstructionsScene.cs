﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using GameUtilities;

namespace ChevEscape
{
    public partial class InstructionsScene : Form
    {
        GameGrid map = new GameGrid();
        Player player;
        Form main_room = new MainRoom();
        ColorPuzzle color_room = new ColorPuzzle();
        ImageRoom image_room = new ImageRoom();

        CloseButton closeButton;
        PauseButton pauseButton;
        MuteButton muteButton;

        public const int roomID = 0;
        public InstructionsScene()
        {
            InitializeComponent();
            InitializeGameComponents();
        }

        private void InstructionsScene_Load(object sender, EventArgs e) { }

        private void InitializeGameComponents()
        {
            player = new Player(map, main_player, 9, 9);
            Door aDoor = new Door(this, main_room,map,door_PB,9,16);
            ActionTile doorAT = new ActionTile(aDoor,map,actionTile_Door,9,15);
            closeButton = new CloseButton(button_close);
            pauseButton = new PauseButton(this, button_pause);
            muteButton = new MuteButton(button_mute);

            map.addToGrid(aDoor);
            map.addToGrid(doorAT);
        }

        private void Button_close_Click(object sender, EventArgs e)
        {
            closeButton.EndGame();
        }

        private void Button_pause_Click(object sender, EventArgs e)
        {
            pauseButton.PauseGame();
        }

        private void InstructionsScene_KeyUp(object sender, KeyEventArgs e)
        {
            player.Move(e.KeyValue);
        }

        private void button_mute_Click(object sender, EventArgs e)
        {
            muteButton.toggleSound();
        }
    }
}
