﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using GameUtilities;

namespace ChevEscape
{
    
    public partial class ColorPuzzle : Form
    {
        //Form mainroom;
        GameGrid map = new GameGrid();
        Player player;
        Form main_room;
        ColorPuzzleManager cpManager;
        Door door;

        public const int COLORPUZZLE_ID = 3;
        CloseButton closeButton;
        PauseButton pauseButton;
        MuteButton muteButton;

        HeartContainer heartA;
        HeartContainer heartB;
        HeartContainer heartC;

        public ColorPuzzle()
        {
            InitializeComponent();
        }

        private void ColorPuzzle_Load(object sender, EventArgs e)
        {
            InitializeGameComponents();
            Program.gameManager.updatePlayersHeartContainer(heartA, heartB, heartC);
            muteButton.updateIcon();
        }

        private void InitializeGameComponents()
        {
            main_room = new MainRoom();
            closeButton = new CloseButton(button_close);
            pauseButton = new PauseButton(this, button_pause);
            muteButton = new MuteButton(button_mute);

            // Player
            player = new Player(map, main_player, 1, 9);

            // Door
            // Setting heart container on screen
            heartA = new HeartContainer(1, heartContainerA);
            heartB = new HeartContainer(2, heartContainerB);
            heartC = new HeartContainer(3, heartContainerC);

            Program.gameManager.updatePlayersHeartContainer(heartA, heartB, heartC);

            door = new Door(this, main_room, map, door_PB, 0, 9);
            ActionTile doorAT = new ActionTile(door, map, actionTile_Door, 1, 9);

            // Instructions
            Instructions instructions = new Instructions(COLORPUZZLE_ID, map, instructionsIcon, 0, 8);
            ActionTile instructionsAT = new ActionTile(instructions, map, actionTile_Instructions, 1, 8);

            /*
             * Color Blocks
             */
            const bool RED = true;
            const bool BLUE = false;

            // Top Row
            ColorBlock colorblockA = new ColorBlock(1, BLUE, map, color_blockA, 5,  5);
            ColorBlock colorblockB = new ColorBlock(2, RED , map, color_blockB, 5, 10);
            ColorBlock colorblockC = new ColorBlock(3, BLUE, map, color_blockC, 5, 15);

            // Middle Row
            ColorBlock colorblockD = new ColorBlock(4,  RED, map, color_blockD, 10,  5);
            ColorBlock colorblockE = new ColorBlock(5, BLUE, map, color_blockE, 10, 10);
            ColorBlock colorblockF = new ColorBlock(6,  RED, map, color_blockF, 10, 15);

            // Bottom Row
            ColorBlock colorblockG = new ColorBlock(7, BLUE, map, color_blockG, 15,  5);
            ColorBlock colorblockH = new ColorBlock(8, RED, map, color_blockH,  15, 10);
            ColorBlock colorblockI = new ColorBlock(9, BLUE, map, color_blockI, 15, 15);

            // Indicator
            Indicator indicator = new Indicator(map, indicatorPB, 0, 7);

            /*
             * Set adjacent pairs
             */
            colorblockA.setAdjacentBlocks(colorblockB, colorblockD);
            colorblockB.setAdjacentBlocks(colorblockA, colorblockC, colorblockE);
            colorblockC.setAdjacentBlocks(colorblockB, colorblockF);

            colorblockD.setAdjacentBlocks(colorblockA, colorblockE, colorblockG);
            colorblockE.setAdjacentBlocks(colorblockB, colorblockD, colorblockF, colorblockH);
            colorblockF.setAdjacentBlocks(colorblockC, colorblockE, colorblockI);

            colorblockG.setAdjacentBlocks(colorblockD, colorblockH);
            colorblockH.setAdjacentBlocks(colorblockG, colorblockE, colorblockI);
            colorblockI.setAdjacentBlocks(colorblockH, colorblockF);

            cpManager = new ColorPuzzleManager(indicator,colorblockA, colorblockB, colorblockC, colorblockD, colorblockE, colorblockF, colorblockG, colorblockH, colorblockI);
            cpManager.monitorPuzzleStatus();
            // Top Row Action Tiles
            // Block @ 5,5
            ActionTile actionTileA1 = new ActionTile(colorblockA, map, actionTile_cbA1, 4, 5); // Top
            ActionTile actionTileA2 = new ActionTile(colorblockA, map, actionTile_cbA2, 5, 4); // Left
            ActionTile actionTileA3 = new ActionTile(colorblockA, map, actionTile_cbA3, 6, 5); // Bottom
            ActionTile actionTileA4 = new ActionTile(colorblockA, map, actionTile_cbA4, 5, 6); // Right

            // Block @ 5,10
            ActionTile actionTileB1 = new ActionTile(colorblockB, map, actionTile_cbB1, 4, 10); // Top
            ActionTile actionTileB2 = new ActionTile(colorblockB, map, actionTile_cbB2, 5, 9); // Left
            ActionTile actionTileB3 = new ActionTile(colorblockB, map, actionTile_cbB3, 6, 10); // Bottom
            ActionTile actionTileB4 = new ActionTile(colorblockB, map, actionTile_cbB4, 5, 11); // Right

            // Block @ 5,15
            ActionTile actionTileC1 = new ActionTile(colorblockC, map, actionTile_cbC1,  4, 15); // Top
            ActionTile actionTileC2 = new ActionTile(colorblockC, map, actionTile_cbC2,  5, 14);  // Left
            ActionTile actionTileC3 = new ActionTile(colorblockC, map, actionTile_cbC3,  6, 15); // Bottom
            ActionTile actionTileC4 = new ActionTile(colorblockC, map, actionTile_cbC4,  5, 16);  // Right

            // Middle Row Action Tiles
            // Block @ 10,5
            ActionTile actionTileD1 = new ActionTile(colorblockD, map, actionTile_cbD1, 9,  5); // Top
            ActionTile actionTileD2 = new ActionTile(colorblockD, map, actionTile_cbD2, 10, 4); // Left
            ActionTile actionTileD3 = new ActionTile(colorblockD, map, actionTile_cbD3, 11, 5); // Bottom
            ActionTile actionTileD4 = new ActionTile(colorblockD, map, actionTile_cbD4, 10, 6); // Right
            // Block @ 10,10
            ActionTile actionTileE1 = new ActionTile(colorblockE, map, actionTile_cbE1,  9, 10); // Top
            ActionTile actionTileE2 = new ActionTile(colorblockE, map, actionTile_cbE2, 10, 9);  // Left
            ActionTile actionTileE3 = new ActionTile(colorblockE, map, actionTile_cbE3, 11, 10); // Bottom
            ActionTile actionTileE4 = new ActionTile(colorblockE, map, actionTile_cbE4, 10, 11); // Right
            // Block @ 10,15
            ActionTile actionTileF1 = new ActionTile(colorblockF, map, actionTile_cbF1, 9, 15);  // Top
            ActionTile actionTileF2 = new ActionTile(colorblockF, map, actionTile_cbF2, 10, 14); // Left
            ActionTile actionTileF3 = new ActionTile(colorblockF, map, actionTile_cbF3, 11, 15); // Bottom
            ActionTile actionTileF4 = new ActionTile(colorblockF, map, actionTile_cbF4, 10, 16); // Right

            // Bottom Row Action Tiles
            // Block @ 15, 5
            ActionTile actionTileG1 = new ActionTile(colorblockG, map, actionTile_cbG1, 14, 5); // Top
            ActionTile actionTileG2 = new ActionTile(colorblockG, map, actionTile_cbG2, 15, 4); // Left
            ActionTile actionTileG3 = new ActionTile(colorblockG, map, actionTile_cbG3, 16, 5); // Bottom
            ActionTile actionTileG4 = new ActionTile(colorblockG, map, actionTile_cbG4, 15, 6); // Right
            // Block @ 15, 10
            ActionTile actionTileH1 = new ActionTile(colorblockH, map, actionTile_cbH1, 14, 10); // Top
            ActionTile actionTileH2 = new ActionTile(colorblockH, map, actionTile_cbH2, 15, 9);  // Left
            ActionTile actionTileH3 = new ActionTile(colorblockH, map, actionTile_cbH3, 16, 10); // Bottom
            ActionTile actionTileH4 = new ActionTile(colorblockH, map, actionTile_cbH4, 15, 11); // Right
            // Block @ 15, 15
            ActionTile actionTileI1 = new ActionTile(colorblockI, map, actionTile_cbI1, 14, 15); // Top
            ActionTile actionTileI2 = new ActionTile(colorblockI, map, actionTile_cbI2, 15, 14); // Left
            ActionTile actionTileI3 = new ActionTile(colorblockI, map, actionTile_cbI3, 16, 15); // Bottom
            ActionTile actionTileI4 = new ActionTile(colorblockI, map, actionTile_cbI4, 15, 16); // Right

            map.addToGrid(door);
            map.addToGrid(doorAT);
            map.addToGrid(indicator);

            map.addToGrid(instructions);
            map.addToGrid(instructionsAT);

            map.addToGrid(colorblockA);
            map.addToGrid(colorblockB);
            map.addToGrid(colorblockC);

            map.addToGrid(actionTileA1);
            map.addToGrid(actionTileA2);
            map.addToGrid(actionTileA3);
            map.addToGrid(actionTileA4);

            map.addToGrid(actionTileB1);
            map.addToGrid(actionTileB2);
            map.addToGrid(actionTileB3);
            map.addToGrid(actionTileB4);

            map.addToGrid(actionTileC1);
            map.addToGrid(actionTileC2);
            map.addToGrid(actionTileC3);
            map.addToGrid(actionTileC4);

            map.addToGrid(colorblockD);
            map.addToGrid(colorblockE);
            map.addToGrid(colorblockF);

            map.addToGrid(actionTileD1);
            map.addToGrid(actionTileD2);
            map.addToGrid(actionTileD3);
            map.addToGrid(actionTileD4);

            map.addToGrid(actionTileE1);
            map.addToGrid(actionTileE2);
            map.addToGrid(actionTileE3);
            map.addToGrid(actionTileE4);

            map.addToGrid(actionTileF1);
            map.addToGrid(actionTileF2);
            map.addToGrid(actionTileF3);
            map.addToGrid(actionTileF4);

            map.addToGrid(colorblockG);
            map.addToGrid(colorblockH);
            map.addToGrid(colorblockI);

            map.addToGrid(actionTileG1);
            map.addToGrid(actionTileG2);
            map.addToGrid(actionTileG3);
            map.addToGrid(actionTileG4);

            map.addToGrid(actionTileH1);
            map.addToGrid(actionTileH2);
            map.addToGrid(actionTileH3);
            map.addToGrid(actionTileH4);

            map.addToGrid(actionTileI1);
            map.addToGrid(actionTileI2);
            map.addToGrid(actionTileI3);
            map.addToGrid(actionTileI4);
        }

        private void Button_close_Click(object sender, EventArgs e)
        {
            closeButton.EndGame();
        }

        private void Button_pause_Click(object sender, EventArgs e)
        {
            pauseButton.PauseGame();
        }

        private void button_mute_Click(object sender, EventArgs e)
        {
            muteButton.toggleSound();
        }

        private void ColorPuzzle_KeyUp(object sender, KeyEventArgs e)
        {
            Program.gameManager.CheckIfGameIsOver(this);
            bool playerPressesActionKey = e.KeyValue == player.getControls_ActionKeyValue();
            bool samePositionAsDoorActionTile = player.getPlayerCurrentPosition_Row() == 1 && player.getPlayerCurrentPosition_Column() == 9;

            // check if the player is setting the action on anything but the action door
            if (playerPressesActionKey && !samePositionAsDoorActionTile) // player has started the puzzle
            {
                cpManager.setIsPuzzleStartedState(true); // puzzle started - what if the puzzle completes and
            }
            // The person is leaving the room without completing the puzzle
            else if (playerPressesActionKey && samePositionAsDoorActionTile)
            {
                // check if the player started the puzzle and is leaving without completing it
                if (cpManager.isPuzzleStarted() && !Program.gameManager.getPuzzleCompletionStatus(COLORPUZZLE_ID))
                {
                    Program.gameManager.decrementAttempts();
                    Program.gameManager.updatePlayersHeartContainer(heartA, heartB, heartC);
                }
            }
            player.Move(e.KeyValue);
            cpManager.monitorPuzzleStatus();
        }
    } // Color Puzzle


    public class ColorPuzzleManager
    {
        
        
        public ColorPuzzleManager(Indicator indc,ColorBlock blockA, ColorBlock blockB, ColorBlock blockC, ColorBlock blockD, ColorBlock blockE, ColorBlock blockF, ColorBlock blockG, ColorBlock blockH, ColorBlock blockI)
        {
            cbA = blockA;
            cbB = blockB;
            cbC = blockC;

            cbD = blockD;
            cbE = blockE;
            cbF = blockF;

            cbG = blockG;
            cbH = blockH;
            cbI = blockI;
            indicator = indc;
        }

        ColorBlock cbA, cbB, cbC, cbD, cbE, cbF, cbG, cbH, cbI;
        Indicator indicator;

        bool puzzleStarted = false;



        const int COLORPUZZLE_ID = 3;
        const bool RED  = true;
        const bool BLUE = false;

        /*
         * Both isPuzzleStarted and setPuzzleState functions are for the player's overall attempts in the game.
         * 
         */
         public bool isPuzzleStarted()      // Checks to see if player started the puzzle
         {
            return puzzleStarted;
         }
        public void setIsPuzzleStartedState(bool state)  // Sets whether this puzzle has started or not
        {
            puzzleStarted = state;
        }

        /*
         * Check if puzzle is complete 
         * - Puzzle is complete when all blocks are blue
         */
        public bool isPuzzleComplete()
        {
            // Top row
            if (cbA.getCurrentState() == RED)
                return false;
            if (cbB.getCurrentState() == RED)
                return false;
            if (cbC.getCurrentState() == RED)
                return false;

            // Middle Row
            if (cbD.getCurrentState() == RED)
                return false;
            if (cbE.getCurrentState() == RED)
                return false;
            if (cbF.getCurrentState() == RED)
                return false;

            // Bottom Row
            if (cbG.getCurrentState() == RED)
                return false;
            if (cbH.getCurrentState() == RED)
                return false;
            if (cbI.getCurrentState() == RED)
                return false;

            return true;
        } // isPuzzleComplete

        public void monitorPuzzleStatus()
        {
            if (Program.gameManager.getPuzzleCompletionStatus(COLORPUZZLE_ID))
            {
                indicator.showCorrectState();
                setBlockColor(BLUE);
            }
            else if (isPuzzleComplete())
            {
                Program.gameManager.setPuzzleCompletionStatus(COLORPUZZLE_ID, true);    // notify game manager that this puzzle is complete.
                // Make puzzle indicator green
                indicator.showCorrectState();
            }
        } // monitorPuzzleSequence

        private void setBlockColor(bool color)
        {
            cbA.setBlockState(color);
            cbB.setBlockState(color);
            cbC.setBlockState(color);

            cbD.setBlockState(color);
            cbE.setBlockState(color);
            cbF.setBlockState(color);

            cbG.setBlockState(color);
            cbH.setBlockState(color);
            cbI.setBlockState(color);
        } // Set block color

    } // Color Puzzle Manager Class

    public class ColorBlock : GameObject
    {
        /*
         * Constructor
         */
        public ColorBlock(int block_id, bool initState, GameGrid map, PictureBox image, int row, int col) :
            base(map, image, row, col)
        {
            blockID = block_id;
            currentState = initState;
            this.setBlockState(currentState);
        }

        /*
         * ColorBlock event
         */
        public void myEvent()
        {
            if (!Program.gameManager.getPuzzleCompletionStatus(puzzleID) )
            {
                // Toggle block states
                toggleBlockState();
                toggleAdjacentBlockStates();

                // Play sound effect
                Program.gameManager.sfxPlay(Properties.Resources.SwitchOn); // Play sound effect
            }
        }


        private int blockID;
        private bool currentState;
        private const bool RED = true;
        private const bool BLUE = false;
        private const int puzzleID = 3;
        ColorBlock adjBlock1 = null, adjBlock2 = null, adjBlock3 = null, adjBlock4 = null;
        //private bool isEnabled = false;

        Image red_block = ChevEscape.Properties.Resources.redBlock;
        Image blue_block = ChevEscape.Properties.Resources.blueBlock;

        

        /*
         * Accessor methods
         */
        public int getColorBlockID()
        {
            return blockID;
        }

        public bool getCurrentState()
        {
            return currentState;
        }

        /*
         * Mutator methods
         */
        public void setBlockState(bool newState)
        {
            if (newState == RED)
            {
                currentState = RED;
                icon.Image = red_block;
            }
            else
            {
                currentState = BLUE;
                icon.Image = blue_block;
            }
            currentState = newState;
        }

        public void setAdjacentBlocks(ColorBlock block1, ColorBlock block2, ColorBlock block3 = null, ColorBlock block4 = null)
        {
            adjBlock1 = block1;
            adjBlock2 = block2;
            adjBlock3 = block3;
            adjBlock4 = block4;
        }

        public void toggleBlockState()
        {
            if (currentState == RED)        // If the current state is RED (true)
            {
                currentState = BLUE;        // Change the current state to BLUE (false)
                icon.Image = blue_block;    // set this block's image to blue
            } // else
            else if (currentState == BLUE)  // If the current state is BLUE (false)
            {
                currentState = RED;         // Change the current state to RED (true) 
                icon.Image = red_block;     // Set this block's image to red
            }
        } // Toggle State

        public void toggleAdjacentBlockStates()
        {
            if (adjBlock1 != null)
            {
                adjBlock1.toggleBlockState();
            }

            if (adjBlock2 != null)
            {
                adjBlock2.toggleBlockState();
            }
            if (adjBlock3 != null)
            {
                adjBlock3.toggleBlockState();
            }

            if (adjBlock4 != null)
            {
                adjBlock4.toggleBlockState();
            }
        } // toggleAdjacentBlockStates

        /*
        public void printMyStatus()
        {
            Console.WriteLine("----------------------------------------------------------------");
            Console.WriteLine("Current Block {0}: State {1}", blockID, currentState);
            Console.WriteLine("----------------------------------------------------------------");

            if (adjBlock1 != null)
            {
                Console.WriteLine("Adjacent Block {0}: State {1}", adjBlock1.getColorBlockID(), adjBlock1.getCurrentState());
            }

            if (adjBlock2 != null)
            {
                Console.WriteLine("Adjacent Block {0}: State {1}", adjBlock2.getColorBlockID(), adjBlock2.getCurrentState());
            }

            if (adjBlock3 != null)
            {
                Console.WriteLine("Adjacent Block {0}: State {1}", adjBlock3.getColorBlockID(), adjBlock3.getCurrentState());
            }

            if (adjBlock4 != null)
            {
                Console.WriteLine("Adjacent Block {0}: State {1}", adjBlock4.getColorBlockID(), adjBlock4.getCurrentState());
            }

            Console.WriteLine("----------------------xxx--xxxxx-----------------------------------");

        } // print my status
        */


    } // ColorBlock class
}
