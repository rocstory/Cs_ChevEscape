﻿namespace ChevEscape
{
    partial class MainRoom
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.heartContainerA = new System.Windows.Forms.PictureBox();
            this.heartContainerC = new System.Windows.Forms.PictureBox();
            this.heartContainerB = new System.Windows.Forms.PictureBox();
            this.button_close = new System.Windows.Forms.PictureBox();
            this.button_pause = new System.Windows.Forms.PictureBox();
            this.main_player = new System.Windows.Forms.PictureBox();
            this.actionTile_instructions = new System.Windows.Forms.PictureBox();
            this.instructionsIcon = new System.Windows.Forms.PictureBox();
            this.door_exit = new System.Windows.Forms.PictureBox();
            this.actionTile_exitDoor = new System.Windows.Forms.PictureBox();
            this.puzzleIndicator_D = new System.Windows.Forms.PictureBox();
            this.puzzleIndicator_C = new System.Windows.Forms.PictureBox();
            this.puzzleIndicator_B = new System.Windows.Forms.PictureBox();
            this.puzzleIndicator_A = new System.Windows.Forms.PictureBox();
            this.actionTile_C = new System.Windows.Forms.PictureBox();
            this.actionTile_D = new System.Windows.Forms.PictureBox();
            this.actionTile_A = new System.Windows.Forms.PictureBox();
            this.actionTile_B = new System.Windows.Forms.PictureBox();
            this.door_D = new System.Windows.Forms.PictureBox();
            this.door_C = new System.Windows.Forms.PictureBox();
            this.door_B = new System.Windows.Forms.PictureBox();
            this.door_A = new System.Windows.Forms.PictureBox();
            this.button_mute = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.heartContainerA)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.heartContainerC)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.heartContainerB)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.button_close)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.button_pause)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.main_player)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.actionTile_instructions)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.instructionsIcon)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.door_exit)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.actionTile_exitDoor)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.puzzleIndicator_D)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.puzzleIndicator_C)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.puzzleIndicator_B)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.puzzleIndicator_A)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.actionTile_C)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.actionTile_D)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.actionTile_A)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.actionTile_B)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.door_D)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.door_C)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.door_B)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.door_A)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.button_mute)).BeginInit();
            this.SuspendLayout();
            // 
            // heartContainerA
            // 
            this.heartContainerA.BackColor = System.Drawing.Color.Transparent;
            this.heartContainerA.Image = global::ChevEscape.Properties.Resources.heart_full;
            this.heartContainerA.Location = new System.Drawing.Point(960, 700);
            this.heartContainerA.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.heartContainerA.Name = "heartContainerA";
            this.heartContainerA.Size = new System.Drawing.Size(64, 62);
            this.heartContainerA.TabIndex = 48;
            this.heartContainerA.TabStop = false;
            // 
            // heartContainerC
            // 
            this.heartContainerC.BackColor = System.Drawing.Color.Transparent;
            this.heartContainerC.Image = global::ChevEscape.Properties.Resources.heart_full;
            this.heartContainerC.Location = new System.Drawing.Point(960, 846);
            this.heartContainerC.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.heartContainerC.Name = "heartContainerC";
            this.heartContainerC.Size = new System.Drawing.Size(64, 62);
            this.heartContainerC.TabIndex = 50;
            this.heartContainerC.TabStop = false;
            // 
            // heartContainerB
            // 
            this.heartContainerB.BackColor = System.Drawing.Color.Transparent;
            this.heartContainerB.Image = global::ChevEscape.Properties.Resources.heart_full;
            this.heartContainerB.Location = new System.Drawing.Point(960, 773);
            this.heartContainerB.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.heartContainerB.Name = "heartContainerB";
            this.heartContainerB.Size = new System.Drawing.Size(64, 62);
            this.heartContainerB.TabIndex = 49;
            this.heartContainerB.TabStop = false;
            // 
            // button_close
            // 
            this.button_close.BackColor = System.Drawing.Color.Transparent;
            this.button_close.Image = global::ChevEscape.Properties.Resources.closeButton;
            this.button_close.Location = new System.Drawing.Point(1128, 23);
            this.button_close.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.button_close.Name = "button_close";
            this.button_close.Size = new System.Drawing.Size(64, 62);
            this.button_close.TabIndex = 12;
            this.button_close.TabStop = false;
            this.button_close.Click += new System.EventHandler(this.Button_close_Click);
            // 
            // button_pause
            // 
            this.button_pause.BackColor = System.Drawing.Color.Transparent;
            this.button_pause.Image = global::ChevEscape.Properties.Resources.pauseButton;
            this.button_pause.Location = new System.Drawing.Point(1052, 23);
            this.button_pause.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.button_pause.Name = "button_pause";
            this.button_pause.Size = new System.Drawing.Size(64, 62);
            this.button_pause.TabIndex = 11;
            this.button_pause.TabStop = false;
            this.button_pause.Click += new System.EventHandler(this.Button_pause_Click);
            // 
            // main_player
            // 
            this.main_player.BackColor = System.Drawing.Color.Transparent;
            this.main_player.Image = global::ChevEscape.Properties.Resources.chev_walkingDown;
            this.main_player.Location = new System.Drawing.Point(1068, 992);
            this.main_player.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.main_player.Name = "main_player";
            this.main_player.Size = new System.Drawing.Size(64, 62);
            this.main_player.TabIndex = 1;
            this.main_player.TabStop = false;
            // 
            // actionTile_instructions
            // 
            this.actionTile_instructions.BackColor = System.Drawing.Color.Transparent;
            this.actionTile_instructions.Image = global::ChevEscape.Properties.Resources.actionTile;
            this.actionTile_instructions.Location = new System.Drawing.Point(552, 992);
            this.actionTile_instructions.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.actionTile_instructions.Name = "actionTile_instructions";
            this.actionTile_instructions.Size = new System.Drawing.Size(64, 62);
            this.actionTile_instructions.TabIndex = 47;
            this.actionTile_instructions.TabStop = false;
            // 
            // instructionsIcon
            // 
            this.instructionsIcon.BackColor = System.Drawing.Color.Transparent;
            this.instructionsIcon.BackgroundImage = global::ChevEscape.Properties.Resources.instructions;
            this.instructionsIcon.Location = new System.Drawing.Point(552, 919);
            this.instructionsIcon.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.instructionsIcon.Name = "instructionsIcon";
            this.instructionsIcon.Size = new System.Drawing.Size(64, 62);
            this.instructionsIcon.TabIndex = 46;
            this.instructionsIcon.TabStop = false;
            // 
            // door_exit
            // 
            this.door_exit.BackColor = System.Drawing.Color.Transparent;
            this.door_exit.Image = global::ChevEscape.Properties.Resources.doorTypeB;
            this.door_exit.Location = new System.Drawing.Point(628, 992);
            this.door_exit.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.door_exit.Name = "door_exit";
            this.door_exit.Size = new System.Drawing.Size(64, 62);
            this.door_exit.TabIndex = 31;
            this.door_exit.TabStop = false;
            // 
            // actionTile_exitDoor
            // 
            this.actionTile_exitDoor.BackColor = System.Drawing.Color.Transparent;
            this.actionTile_exitDoor.Image = global::ChevEscape.Properties.Resources.actionTile;
            this.actionTile_exitDoor.Location = new System.Drawing.Point(628, 919);
            this.actionTile_exitDoor.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.actionTile_exitDoor.Name = "actionTile_exitDoor";
            this.actionTile_exitDoor.Size = new System.Drawing.Size(64, 62);
            this.actionTile_exitDoor.TabIndex = 30;
            this.actionTile_exitDoor.TabStop = false;
            // 
            // puzzleIndicator_D
            // 
            this.puzzleIndicator_D.BackColor = System.Drawing.Color.Transparent;
            this.puzzleIndicator_D.Image = global::ChevEscape.Properties.Resources.indicator_neutral;
            this.puzzleIndicator_D.Location = new System.Drawing.Point(628, 627);
            this.puzzleIndicator_D.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.puzzleIndicator_D.Name = "puzzleIndicator_D";
            this.puzzleIndicator_D.Size = new System.Drawing.Size(64, 62);
            this.puzzleIndicator_D.TabIndex = 29;
            this.puzzleIndicator_D.TabStop = false;
            // 
            // puzzleIndicator_C
            // 
            this.puzzleIndicator_C.BackColor = System.Drawing.Color.Transparent;
            this.puzzleIndicator_C.Image = global::ChevEscape.Properties.Resources.indicator_neutral;
            this.puzzleIndicator_C.Location = new System.Drawing.Point(628, 700);
            this.puzzleIndicator_C.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.puzzleIndicator_C.Name = "puzzleIndicator_C";
            this.puzzleIndicator_C.Size = new System.Drawing.Size(64, 62);
            this.puzzleIndicator_C.TabIndex = 28;
            this.puzzleIndicator_C.TabStop = false;
            // 
            // puzzleIndicator_B
            // 
            this.puzzleIndicator_B.BackColor = System.Drawing.Color.Transparent;
            this.puzzleIndicator_B.Image = global::ChevEscape.Properties.Resources.indicator_neutral;
            this.puzzleIndicator_B.Location = new System.Drawing.Point(628, 773);
            this.puzzleIndicator_B.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.puzzleIndicator_B.Name = "puzzleIndicator_B";
            this.puzzleIndicator_B.Size = new System.Drawing.Size(64, 62);
            this.puzzleIndicator_B.TabIndex = 27;
            this.puzzleIndicator_B.TabStop = false;
            // 
            // puzzleIndicator_A
            // 
            this.puzzleIndicator_A.BackColor = System.Drawing.Color.Transparent;
            this.puzzleIndicator_A.Image = global::ChevEscape.Properties.Resources.indicator_neutral;
            this.puzzleIndicator_A.Location = new System.Drawing.Point(628, 846);
            this.puzzleIndicator_A.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.puzzleIndicator_A.Name = "puzzleIndicator_A";
            this.puzzleIndicator_A.Size = new System.Drawing.Size(64, 62);
            this.puzzleIndicator_A.TabIndex = 26;
            this.puzzleIndicator_A.TabStop = false;
            this.puzzleIndicator_A.Click += new System.EventHandler(this.PuzzleIndicator_A_Click);
            // 
            // actionTile_C
            // 
            this.actionTile_C.BackColor = System.Drawing.Color.Transparent;
            this.actionTile_C.Image = global::ChevEscape.Properties.Resources.actionTile;
            this.actionTile_C.Location = new System.Drawing.Point(808, 919);
            this.actionTile_C.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.actionTile_C.Name = "actionTile_C";
            this.actionTile_C.Size = new System.Drawing.Size(64, 62);
            this.actionTile_C.TabIndex = 10;
            this.actionTile_C.TabStop = false;
            // 
            // actionTile_D
            // 
            this.actionTile_D.BackColor = System.Drawing.Color.Transparent;
            this.actionTile_D.Image = global::ChevEscape.Properties.Resources.actionTile;
            this.actionTile_D.Location = new System.Drawing.Point(732, 919);
            this.actionTile_D.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.actionTile_D.Name = "actionTile_D";
            this.actionTile_D.Size = new System.Drawing.Size(64, 62);
            this.actionTile_D.TabIndex = 9;
            this.actionTile_D.TabStop = false;
            // 
            // actionTile_A
            // 
            this.actionTile_A.BackColor = System.Drawing.Color.Transparent;
            this.actionTile_A.Image = global::ChevEscape.Properties.Resources.actionTile;
            this.actionTile_A.Location = new System.Drawing.Point(960, 919);
            this.actionTile_A.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.actionTile_A.Name = "actionTile_A";
            this.actionTile_A.Size = new System.Drawing.Size(64, 62);
            this.actionTile_A.TabIndex = 8;
            this.actionTile_A.TabStop = false;
            // 
            // actionTile_B
            // 
            this.actionTile_B.BackColor = System.Drawing.Color.Transparent;
            this.actionTile_B.Image = global::ChevEscape.Properties.Resources.actionTile;
            this.actionTile_B.Location = new System.Drawing.Point(884, 919);
            this.actionTile_B.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.actionTile_B.Name = "actionTile_B";
            this.actionTile_B.Size = new System.Drawing.Size(64, 62);
            this.actionTile_B.TabIndex = 7;
            this.actionTile_B.TabStop = false;
            // 
            // door_D
            // 
            this.door_D.BackColor = System.Drawing.Color.Transparent;
            this.door_D.Image = global::ChevEscape.Properties.Resources.doorTypeA;
            this.door_D.Location = new System.Drawing.Point(732, 992);
            this.door_D.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.door_D.Name = "door_D";
            this.door_D.Size = new System.Drawing.Size(64, 62);
            this.door_D.TabIndex = 5;
            this.door_D.TabStop = false;
            // 
            // door_C
            // 
            this.door_C.BackColor = System.Drawing.Color.Transparent;
            this.door_C.Image = global::ChevEscape.Properties.Resources.doorTypeA;
            this.door_C.Location = new System.Drawing.Point(808, 992);
            this.door_C.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.door_C.Name = "door_C";
            this.door_C.Size = new System.Drawing.Size(64, 62);
            this.door_C.TabIndex = 4;
            this.door_C.TabStop = false;
            // 
            // door_B
            // 
            this.door_B.BackColor = System.Drawing.Color.Transparent;
            this.door_B.Image = global::ChevEscape.Properties.Resources.doorTypeA;
            this.door_B.Location = new System.Drawing.Point(884, 992);
            this.door_B.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.door_B.Name = "door_B";
            this.door_B.Size = new System.Drawing.Size(64, 62);
            this.door_B.TabIndex = 3;
            this.door_B.TabStop = false;
            // 
            // door_A
            // 
            this.door_A.BackColor = System.Drawing.Color.Transparent;
            this.door_A.Image = global::ChevEscape.Properties.Resources.doorTypeA;
            this.door_A.Location = new System.Drawing.Point(960, 992);
            this.door_A.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.door_A.Name = "door_A";
            this.door_A.Size = new System.Drawing.Size(64, 62);
            this.door_A.TabIndex = 2;
            this.door_A.TabStop = false;
            // 
            // button_mute
            // 
            this.button_mute.BackColor = System.Drawing.Color.Transparent;
            this.button_mute.Image = global::ChevEscape.Properties.Resources.Unmuted;
            this.button_mute.Location = new System.Drawing.Point(1128, 97);
            this.button_mute.Margin = new System.Windows.Forms.Padding(6);
            this.button_mute.Name = "button_mute";
            this.button_mute.Size = new System.Drawing.Size(64, 62);
            this.button_mute.TabIndex = 51;
            this.button_mute.TabStop = false;
            this.button_mute.Click += new System.EventHandler(this.button_mute_Click);
            // 
            // MainRoom
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.DimGray;
            this.ClientSize = new System.Drawing.Size(1216, 1169);
            this.Controls.Add(this.button_mute);
            this.Controls.Add(this.heartContainerA);
            this.Controls.Add(this.heartContainerC);
            this.Controls.Add(this.heartContainerB);
            this.Controls.Add(this.button_close);
            this.Controls.Add(this.button_pause);
            this.Controls.Add(this.main_player);
            this.Controls.Add(this.actionTile_instructions);
            this.Controls.Add(this.instructionsIcon);
            this.Controls.Add(this.door_exit);
            this.Controls.Add(this.actionTile_exitDoor);
            this.Controls.Add(this.puzzleIndicator_D);
            this.Controls.Add(this.puzzleIndicator_C);
            this.Controls.Add(this.puzzleIndicator_B);
            this.Controls.Add(this.puzzleIndicator_A);
            this.Controls.Add(this.actionTile_C);
            this.Controls.Add(this.actionTile_D);
            this.Controls.Add(this.actionTile_A);
            this.Controls.Add(this.actionTile_B);
            this.Controls.Add(this.door_D);
            this.Controls.Add(this.door_C);
            this.Controls.Add(this.door_B);
            this.Controls.Add(this.door_A);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.KeyPreview = true;
            this.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.MaximumSize = new System.Drawing.Size(1216, 1169);
            this.MinimumSize = new System.Drawing.Size(1216, 1169);
            this.Name = "MainRoom";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "MainRoom";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.MainRoom_FormClosing);
            this.Load += new System.EventHandler(this.MainRoom_Load);
            this.KeyUp += new System.Windows.Forms.KeyEventHandler(this.MainRoom_KeyUp);
            ((System.ComponentModel.ISupportInitialize)(this.heartContainerA)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.heartContainerC)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.heartContainerB)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.button_close)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.button_pause)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.main_player)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.actionTile_instructions)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.instructionsIcon)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.door_exit)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.actionTile_exitDoor)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.puzzleIndicator_D)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.puzzleIndicator_C)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.puzzleIndicator_B)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.puzzleIndicator_A)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.actionTile_C)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.actionTile_D)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.actionTile_A)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.actionTile_B)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.door_D)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.door_C)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.door_B)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.door_A)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.button_mute)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.PictureBox main_player;
        private System.Windows.Forms.PictureBox door_A;
        private System.Windows.Forms.PictureBox door_B;
        private System.Windows.Forms.PictureBox door_C;
        private System.Windows.Forms.PictureBox door_D;
        private System.Windows.Forms.PictureBox actionTile_B;
        private System.Windows.Forms.PictureBox actionTile_A;
        private System.Windows.Forms.PictureBox actionTile_D;
        private System.Windows.Forms.PictureBox actionTile_C;
        private System.Windows.Forms.PictureBox button_pause;
        private System.Windows.Forms.PictureBox button_close;
        private System.Windows.Forms.PictureBox puzzleIndicator_A;
        private System.Windows.Forms.PictureBox puzzleIndicator_B;
        private System.Windows.Forms.PictureBox puzzleIndicator_C;
        private System.Windows.Forms.PictureBox puzzleIndicator_D;
        private System.Windows.Forms.PictureBox actionTile_exitDoor;
        private System.Windows.Forms.PictureBox door_exit;
        private System.Windows.Forms.PictureBox instructionsIcon;
        private System.Windows.Forms.PictureBox actionTile_instructions;
        private System.Windows.Forms.PictureBox heartContainerA;
        private System.Windows.Forms.PictureBox heartContainerB;
        private System.Windows.Forms.PictureBox heartContainerC;
        private System.Windows.Forms.PictureBox button_mute;
    }
}