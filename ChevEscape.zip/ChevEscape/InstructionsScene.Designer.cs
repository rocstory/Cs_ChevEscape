﻿namespace ChevEscape
{
    partial class InstructionsScene
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.main_player = new System.Windows.Forms.PictureBox();
            this.actionTile_Door = new System.Windows.Forms.PictureBox();
            this.door_PB = new System.Windows.Forms.PictureBox();
            this.movementLabel = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.button_pause = new System.Windows.Forms.PictureBox();
            this.button_close = new System.Windows.Forms.PictureBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.button_mute = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.main_player)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.actionTile_Door)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.door_PB)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.button_pause)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.button_close)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.button_mute)).BeginInit();
            this.SuspendLayout();
            // 
            // main_player
            // 
            this.main_player.BackColor = System.Drawing.Color.Transparent;
            this.main_player.Image = global::ChevEscape.Properties.Resources.chev_walkingDown;
            this.main_player.Location = new System.Drawing.Point(548, 552);
            this.main_player.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.main_player.Name = "main_player";
            this.main_player.Size = new System.Drawing.Size(64, 62);
            this.main_player.TabIndex = 59;
            this.main_player.TabStop = false;
            // 
            // actionTile_Door
            // 
            this.actionTile_Door.BackColor = System.Drawing.Color.Transparent;
            this.actionTile_Door.Image = global::ChevEscape.Properties.Resources.actionTile;
            this.actionTile_Door.Location = new System.Drawing.Point(950, 552);
            this.actionTile_Door.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.actionTile_Door.Name = "actionTile_Door";
            this.actionTile_Door.Size = new System.Drawing.Size(64, 62);
            this.actionTile_Door.TabIndex = 61;
            this.actionTile_Door.TabStop = false;
            // 
            // door_PB
            // 
            this.door_PB.BackColor = System.Drawing.Color.Transparent;
            this.door_PB.Image = global::ChevEscape.Properties.Resources.doorTypeA;
            this.door_PB.Location = new System.Drawing.Point(1026, 552);
            this.door_PB.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.door_PB.Name = "door_PB";
            this.door_PB.Size = new System.Drawing.Size(64, 62);
            this.door_PB.TabIndex = 60;
            this.door_PB.TabStop = false;
            // 
            // movementLabel
            // 
            this.movementLabel.AutoSize = true;
            this.movementLabel.BackColor = System.Drawing.Color.White;
            this.movementLabel.Font = new System.Drawing.Font("MS Gothic", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.movementLabel.Location = new System.Drawing.Point(354, 221);
            this.movementLabel.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.movementLabel.Name = "movementLabel";
            this.movementLabel.Size = new System.Drawing.Size(475, 58);
            this.movementLabel.TabIndex = 62;
            this.movementLabel.Text = "W,A,S,D to move";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.White;
            this.label1.Font = new System.Drawing.Font("MS Gothic", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(46, 277);
            this.label1.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(1045, 58);
            this.label1.TabIndex = 63;
            this.label1.Text = "Up, Down, Left, Right Respectively";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.White;
            this.label2.Font = new System.Drawing.Font("MS Gothic", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(104, 710);
            this.label2.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(925, 58);
            this.label2.TabIndex = 64;
            this.label2.Text = "Press F to activate action key";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.White;
            this.label3.Font = new System.Drawing.Font("MS Gothic", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(496, 165);
            this.label3.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(175, 58);
            this.label3.TabIndex = 65;
            this.label3.Text = "Press";
            // 
            // button_pause
            // 
            this.button_pause.BackColor = System.Drawing.Color.Transparent;
            this.button_pause.Image = global::ChevEscape.Properties.Resources.pauseButton;
            this.button_pause.Location = new System.Drawing.Point(994, 1010);
            this.button_pause.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.button_pause.Name = "button_pause";
            this.button_pause.Size = new System.Drawing.Size(64, 62);
            this.button_pause.TabIndex = 69;
            this.button_pause.TabStop = false;
            this.button_pause.Click += new System.EventHandler(this.Button_pause_Click);
            // 
            // button_close
            // 
            this.button_close.BackColor = System.Drawing.Color.Transparent;
            this.button_close.Image = global::ChevEscape.Properties.Resources.closeButton;
            this.button_close.Location = new System.Drawing.Point(1070, 1010);
            this.button_close.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.button_close.Name = "button_close";
            this.button_close.Size = new System.Drawing.Size(64, 62);
            this.button_close.TabIndex = 68;
            this.button_close.TabStop = false;
            this.button_close.Click += new System.EventHandler(this.Button_close_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.White;
            this.label4.Font = new System.Drawing.Font("MS Gothic", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(24, 833);
            this.label4.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(775, 58);
            this.label4.TabIndex = 70;
            this.label4.Text = "Move onto the Action Tile";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.White;
            this.label5.Font = new System.Drawing.Font("MS Gothic", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(264, 888);
            this.label5.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(745, 58);
            this.label5.TabIndex = 71;
            this.label5.Text = "and press F to continue.";
            // 
            // button_mute
            // 
            this.button_mute.BackColor = System.Drawing.Color.Transparent;
            this.button_mute.Image = global::ChevEscape.Properties.Resources.Unmuted;
            this.button_mute.Location = new System.Drawing.Point(918, 1010);
            this.button_mute.Margin = new System.Windows.Forms.Padding(6);
            this.button_mute.Name = "button_mute";
            this.button_mute.Size = new System.Drawing.Size(64, 62);
            this.button_mute.TabIndex = 72;
            this.button_mute.TabStop = false;
            this.button_mute.Click += new System.EventHandler(this.button_mute_Click);
            // 
            // InstructionsScene
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.DarkGray;
            this.ClientSize = new System.Drawing.Size(1216, 1169);
            this.Controls.Add(this.button_mute);
            this.Controls.Add(this.main_player);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.button_pause);
            this.Controls.Add(this.button_close);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.actionTile_Door);
            this.Controls.Add(this.door_PB);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.movementLabel);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.KeyPreview = true;
            this.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.MaximumSize = new System.Drawing.Size(1216, 1169);
            this.MinimumSize = new System.Drawing.Size(1216, 1169);
            this.Name = "InstructionsScene";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "InstructionsScene";
            this.Load += new System.EventHandler(this.InstructionsScene_Load);
            this.KeyUp += new System.Windows.Forms.KeyEventHandler(this.InstructionsScene_KeyUp);
            ((System.ComponentModel.ISupportInitialize)(this.main_player)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.actionTile_Door)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.door_PB)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.button_pause)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.button_close)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.button_mute)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox main_player;
        private System.Windows.Forms.PictureBox actionTile_Door;
        private System.Windows.Forms.PictureBox door_PB;
        private System.Windows.Forms.Label movementLabel;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.PictureBox button_pause;
        private System.Windows.Forms.PictureBox button_close;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.PictureBox button_mute;
    }
}