﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using GameUtilities;

namespace ChevEscape
{
    public partial class WinningGameScene : Form
    {
        CloseButton closeButton;
        PauseButton pauseButton;
        public WinningGameScene()
        {
            InitializeComponent();
            

        }

        private void Button_close_Click(object sender, EventArgs e)
        {
            closeButton.EndGame();
        }

        private void WinningGameScene_Load(object sender, EventArgs e)
        {
            closeButton = new CloseButton(button_close);
            pauseButton = new PauseButton(this, button_pause);
        }

        private void Button_pause_Click(object sender, EventArgs e)
        {
            pauseButton.PauseGame();
        }

        private void Label1_Click(object sender, EventArgs e)
        {

        }

        private void Label2_Click(object sender, EventArgs e)
        {

        }

        private void PlayAgain_Click(object sender, EventArgs e)
        {
            
            GameMenu menu = new GameMenu();
            menu.Show();
            this.Close();
            Program.gameManager.resetPuzzleRoomData();

        }

        private void EndGame_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
