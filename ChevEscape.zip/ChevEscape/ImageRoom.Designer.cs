﻿namespace ChevEscape
{
    partial class ImageRoom
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.desk_upperLeftIcon = new System.Windows.Forms.PictureBox();
            this.desk_lowerLeftIcon = new System.Windows.Forms.PictureBox();
            this.desk_upperRightIcon = new System.Windows.Forms.PictureBox();
            this.desk_lowerRightIcon = new System.Windows.Forms.PictureBox();
            this.actionTile_Instructions = new System.Windows.Forms.PictureBox();
            this.instructionsIcon = new System.Windows.Forms.PictureBox();
            this.actionTile_Door = new System.Windows.Forms.PictureBox();
            this.door_PB = new System.Windows.Forms.PictureBox();
            this.main_player = new System.Windows.Forms.PictureBox();
            this.actionTile_imageScramblerObject = new System.Windows.Forms.PictureBox();
            this.button_close = new System.Windows.Forms.PictureBox();
            this.button_pause = new System.Windows.Forms.PictureBox();
            this.heartContainer1 = new System.Windows.Forms.PictureBox();
            this.heartContainer2 = new System.Windows.Forms.PictureBox();
            this.heartContainer3 = new System.Windows.Forms.PictureBox();
            this.button_mute = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.desk_upperLeftIcon)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.desk_lowerLeftIcon)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.desk_upperRightIcon)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.desk_lowerRightIcon)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.actionTile_Instructions)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.instructionsIcon)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.actionTile_Door)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.door_PB)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.main_player)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.actionTile_imageScramblerObject)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.button_close)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.button_pause)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.heartContainer1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.heartContainer2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.heartContainer3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.button_mute)).BeginInit();
            this.SuspendLayout();
            // 
            // desk_upperLeftIcon
            // 
            this.desk_upperLeftIcon.BackColor = System.Drawing.Color.Transparent;
            this.desk_upperLeftIcon.Image = global::ChevEscape.Properties.Resources.desk_upperLeftCorner;
            this.desk_upperLeftIcon.Location = new System.Drawing.Point(378, 526);
            this.desk_upperLeftIcon.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.desk_upperLeftIcon.Name = "desk_upperLeftIcon";
            this.desk_upperLeftIcon.Size = new System.Drawing.Size(32, 32);
            this.desk_upperLeftIcon.TabIndex = 64;
            this.desk_upperLeftIcon.TabStop = false;
            // 
            // desk_lowerLeftIcon
            // 
            this.desk_lowerLeftIcon.BackColor = System.Drawing.Color.Transparent;
            this.desk_lowerLeftIcon.Image = global::ChevEscape.Properties.Resources.desk_lowerLeftCorner;
            this.desk_lowerLeftIcon.Location = new System.Drawing.Point(378, 564);
            this.desk_lowerLeftIcon.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.desk_lowerLeftIcon.Name = "desk_lowerLeftIcon";
            this.desk_lowerLeftIcon.Size = new System.Drawing.Size(32, 32);
            this.desk_lowerLeftIcon.TabIndex = 63;
            this.desk_lowerLeftIcon.TabStop = false;
            // 
            // desk_upperRightIcon
            // 
            this.desk_upperRightIcon.BackColor = System.Drawing.Color.Transparent;
            this.desk_upperRightIcon.Image = global::ChevEscape.Properties.Resources.desk_upperRightCorner;
            this.desk_upperRightIcon.Location = new System.Drawing.Point(416, 526);
            this.desk_upperRightIcon.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.desk_upperRightIcon.Name = "desk_upperRightIcon";
            this.desk_upperRightIcon.Size = new System.Drawing.Size(32, 32);
            this.desk_upperRightIcon.TabIndex = 62;
            this.desk_upperRightIcon.TabStop = false;
            // 
            // desk_lowerRightIcon
            // 
            this.desk_lowerRightIcon.BackColor = System.Drawing.Color.Transparent;
            this.desk_lowerRightIcon.Image = global::ChevEscape.Properties.Resources.desk_lowerRightCorner;
            this.desk_lowerRightIcon.Location = new System.Drawing.Point(416, 564);
            this.desk_lowerRightIcon.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.desk_lowerRightIcon.Name = "desk_lowerRightIcon";
            this.desk_lowerRightIcon.Size = new System.Drawing.Size(32, 32);
            this.desk_lowerRightIcon.TabIndex = 61;
            this.desk_lowerRightIcon.TabStop = false;
            // 
            // actionTile_Instructions
            // 
            this.actionTile_Instructions.BackColor = System.Drawing.Color.Transparent;
            this.actionTile_Instructions.Image = global::ChevEscape.Properties.Resources.actionTile;
            this.actionTile_Instructions.Location = new System.Drawing.Point(488, 526);
            this.actionTile_Instructions.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.actionTile_Instructions.Name = "actionTile_Instructions";
            this.actionTile_Instructions.Size = new System.Drawing.Size(32, 32);
            this.actionTile_Instructions.TabIndex = 60;
            this.actionTile_Instructions.TabStop = false;
            // 
            // instructionsIcon
            // 
            this.instructionsIcon.BackColor = System.Drawing.Color.Transparent;
            this.instructionsIcon.Image = global::ChevEscape.Properties.Resources.instructions;
            this.instructionsIcon.Location = new System.Drawing.Point(488, 564);
            this.instructionsIcon.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.instructionsIcon.Name = "instructionsIcon";
            this.instructionsIcon.Size = new System.Drawing.Size(32, 32);
            this.instructionsIcon.TabIndex = 59;
            this.instructionsIcon.TabStop = false;
            // 
            // actionTile_Door
            // 
            this.actionTile_Door.BackColor = System.Drawing.Color.Transparent;
            this.actionTile_Door.Image = global::ChevEscape.Properties.Resources.actionTile;
            this.actionTile_Door.Location = new System.Drawing.Point(526, 526);
            this.actionTile_Door.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.actionTile_Door.Name = "actionTile_Door";
            this.actionTile_Door.Size = new System.Drawing.Size(32, 32);
            this.actionTile_Door.TabIndex = 58;
            this.actionTile_Door.TabStop = false;
            // 
            // door_PB
            // 
            this.door_PB.BackColor = System.Drawing.Color.Transparent;
            this.door_PB.Image = global::ChevEscape.Properties.Resources.doorTypeA;
            this.door_PB.Location = new System.Drawing.Point(526, 564);
            this.door_PB.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.door_PB.Name = "door_PB";
            this.door_PB.Size = new System.Drawing.Size(32, 32);
            this.door_PB.TabIndex = 57;
            this.door_PB.TabStop = false;
            // 
            // main_player
            // 
            this.main_player.BackColor = System.Drawing.Color.Transparent;
            this.main_player.Image = global::ChevEscape.Properties.Resources.chev_mainPlayer;
            this.main_player.Location = new System.Drawing.Point(564, 564);
            this.main_player.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.main_player.Name = "main_player";
            this.main_player.Size = new System.Drawing.Size(32, 32);
            this.main_player.TabIndex = 2;
            this.main_player.TabStop = false;
            // 
            // actionTile_imageScramblerObject
            // 
            this.actionTile_imageScramblerObject.BackColor = System.Drawing.Color.Transparent;
            this.actionTile_imageScramblerObject.Image = global::ChevEscape.Properties.Resources.actionTile;
            this.actionTile_imageScramblerObject.Location = new System.Drawing.Point(416, 488);
            this.actionTile_imageScramblerObject.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.actionTile_imageScramblerObject.Name = "actionTile_imageScramblerObject";
            this.actionTile_imageScramblerObject.Size = new System.Drawing.Size(32, 32);
            this.actionTile_imageScramblerObject.TabIndex = 65;
            this.actionTile_imageScramblerObject.TabStop = false;
            // 
            // button_close
            // 
            this.button_close.BackColor = System.Drawing.Color.Transparent;
            this.button_close.Image = global::ChevEscape.Properties.Resources.closeButton;
            this.button_close.Location = new System.Drawing.Point(326, 564);
            this.button_close.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.button_close.Name = "button_close";
            this.button_close.Size = new System.Drawing.Size(32, 32);
            this.button_close.TabIndex = 66;
            this.button_close.TabStop = false;
            this.button_close.Click += new System.EventHandler(this.Button_close_Click);
            // 
            // button_pause
            // 
            this.button_pause.BackColor = System.Drawing.Color.Transparent;
            this.button_pause.Image = global::ChevEscape.Properties.Resources.pauseButton;
            this.button_pause.Location = new System.Drawing.Point(288, 564);
            this.button_pause.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.button_pause.Name = "button_pause";
            this.button_pause.Size = new System.Drawing.Size(32, 32);
            this.button_pause.TabIndex = 67;
            this.button_pause.TabStop = false;
            this.button_pause.Click += new System.EventHandler(this.Button_pause_Click);
            // 
            // heartContainer1
            // 
            this.heartContainer1.BackColor = System.Drawing.Color.Transparent;
            this.heartContainer1.Image = global::ChevEscape.Properties.Resources.heart_full;
            this.heartContainer1.Location = new System.Drawing.Point(288, 288);
            this.heartContainer1.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.heartContainer1.Name = "heartContainer1";
            this.heartContainer1.Size = new System.Drawing.Size(32, 32);
            this.heartContainer1.TabIndex = 68;
            this.heartContainer1.TabStop = false;
            // 
            // heartContainer2
            // 
            this.heartContainer2.BackColor = System.Drawing.Color.Transparent;
            this.heartContainer2.Image = global::ChevEscape.Properties.Resources.heart_full;
            this.heartContainer2.Location = new System.Drawing.Point(288, 327);
            this.heartContainer2.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.heartContainer2.Name = "heartContainer2";
            this.heartContainer2.Size = new System.Drawing.Size(32, 32);
            this.heartContainer2.TabIndex = 69;
            this.heartContainer2.TabStop = false;
            // 
            // heartContainer3
            // 
            this.heartContainer3.BackColor = System.Drawing.Color.Transparent;
            this.heartContainer3.Image = global::ChevEscape.Properties.Resources.heart_full;
            this.heartContainer3.Location = new System.Drawing.Point(288, 365);
            this.heartContainer3.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.heartContainer3.Name = "heartContainer3";
            this.heartContainer3.Size = new System.Drawing.Size(32, 32);
            this.heartContainer3.TabIndex = 70;
            this.heartContainer3.TabStop = false;
            // 
            // button_mute
            // 
            this.button_mute.BackColor = System.Drawing.Color.Transparent;
            this.button_mute.Image = global::ChevEscape.Properties.Resources.Unmuted;
            this.button_mute.Location = new System.Drawing.Point(251, 564);
            this.button_mute.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.button_mute.Name = "button_mute";
            this.button_mute.Size = new System.Drawing.Size(32, 32);
            this.button_mute.TabIndex = 71;
            this.button_mute.TabStop = false;
            this.button_mute.Click += new System.EventHandler(this.button_mute_Click);
            // 
            // ImageRoom
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.SandyBrown;
            this.ClientSize = new System.Drawing.Size(608, 572);
            this.Controls.Add(this.button_mute);
            this.Controls.Add(this.heartContainer3);
            this.Controls.Add(this.heartContainer2);
            this.Controls.Add(this.heartContainer1);
            this.Controls.Add(this.button_pause);
            this.Controls.Add(this.button_close);
            this.Controls.Add(this.main_player);
            this.Controls.Add(this.actionTile_imageScramblerObject);
            this.Controls.Add(this.desk_upperLeftIcon);
            this.Controls.Add(this.desk_lowerLeftIcon);
            this.Controls.Add(this.desk_upperRightIcon);
            this.Controls.Add(this.desk_lowerRightIcon);
            this.Controls.Add(this.actionTile_Instructions);
            this.Controls.Add(this.instructionsIcon);
            this.Controls.Add(this.actionTile_Door);
            this.Controls.Add(this.door_PB);
            this.ForeColor = System.Drawing.SystemColors.ControlText;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.KeyPreview = true;
            this.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.MaximumSize = new System.Drawing.Size(608, 608);
            this.MinimumSize = new System.Drawing.Size(608, 540);
            this.Name = "ImageRoom";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "ImageRoom";
            this.Load += new System.EventHandler(this.ImageRoom_Load);
            this.KeyUp += new System.Windows.Forms.KeyEventHandler(this.ImageRoom_KeyUp);
            ((System.ComponentModel.ISupportInitialize)(this.desk_upperLeftIcon)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.desk_lowerLeftIcon)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.desk_upperRightIcon)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.desk_lowerRightIcon)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.actionTile_Instructions)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.instructionsIcon)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.actionTile_Door)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.door_PB)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.main_player)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.actionTile_imageScramblerObject)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.button_close)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.button_pause)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.heartContainer1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.heartContainer2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.heartContainer3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.button_mute)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.PictureBox main_player;
        private System.Windows.Forms.PictureBox door_PB;
        private System.Windows.Forms.PictureBox actionTile_Door;
        private System.Windows.Forms.PictureBox instructionsIcon;
        private System.Windows.Forms.PictureBox actionTile_Instructions;
        private System.Windows.Forms.PictureBox desk_upperLeftIcon;
        private System.Windows.Forms.PictureBox desk_lowerLeftIcon;
        private System.Windows.Forms.PictureBox desk_upperRightIcon;
        private System.Windows.Forms.PictureBox desk_lowerRightIcon;
        private System.Windows.Forms.PictureBox actionTile_imageScramblerObject;
        private System.Windows.Forms.PictureBox button_close;
        private System.Windows.Forms.PictureBox button_pause;
        private System.Windows.Forms.PictureBox heartContainer1;
        private System.Windows.Forms.PictureBox heartContainer2;
        private System.Windows.Forms.PictureBox heartContainer3;
        private System.Windows.Forms.PictureBox button_mute;
    }
}