﻿namespace ChevEscape
{
    partial class GameMenu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.button_exit = new System.Windows.Forms.Button();
            this.button_play = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // button_exit
            // 
            this.button_exit.BackgroundImage = global::ChevEscape.Properties.Resources.buttonBGMainScreen;
            this.button_exit.Font = new System.Drawing.Font("MS Gothic", 39.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_exit.Location = new System.Drawing.Point(348, 249);
            this.button_exit.Name = "button_exit";
            this.button_exit.Size = new System.Drawing.Size(232, 80);
            this.button_exit.TabIndex = 1;
            this.button_exit.Text = "EXIT";
            this.button_exit.UseVisualStyleBackColor = true;
            this.button_exit.Click += new System.EventHandler(this.Button_exit_Click);
            this.button_exit.MouseLeave += new System.EventHandler(this.Button_exit_MouseLeave);
            this.button_exit.MouseHover += new System.EventHandler(this.Button_exit_MouseHover);
            // 
            // button_play
            // 
            this.button_play.BackgroundImage = global::ChevEscape.Properties.Resources.buttonBGMainScreen;
            this.button_play.Font = new System.Drawing.Font("MS Gothic", 39.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_play.Location = new System.Drawing.Point(348, 141);
            this.button_play.Name = "button_play";
            this.button_play.Size = new System.Drawing.Size(232, 80);
            this.button_play.TabIndex = 0;
            this.button_play.Text = "PLAY";
            this.button_play.UseVisualStyleBackColor = true;
            this.button_play.Click += new System.EventHandler(this.Button_play_Click);
            this.button_play.MouseLeave += new System.EventHandler(this.Button_play_MouseLeave);
            this.button_play.MouseHover += new System.EventHandler(this.Button_play_MouseHover);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.DarkGray;
            this.label1.Font = new System.Drawing.Font("MS Gothic", 48F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(86, 38);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(444, 64);
            this.label1.TabIndex = 7;
            this.label1.Text = "Chev\'s Escape";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.White;
            this.label2.Font = new System.Drawing.Font("MS Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(7, 579);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(592, 16);
            this.label2.TabIndex = 8;
            this.label2.Text = "Krishan Singh, Stephen Alpuche, Malik Roc, Matheus Alexandre, Cory Pineau";
            // 
            // GameMenu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.DimGray;
            this.BackgroundImage = global::ChevEscape.Properties.Resources.ChevEscape_MainMenuBackground;
            this.ClientSize = new System.Drawing.Size(608, 608);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.button_exit);
            this.Controls.Add(this.button_play);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.MaximumSize = new System.Drawing.Size(608, 608);
            this.MinimumSize = new System.Drawing.Size(608, 608);
            this.Name = "GameMenu";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "ChevEscape";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button_play;
        private System.Windows.Forms.Button button_exit;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
    }
}

